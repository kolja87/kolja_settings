from mathutils import Matrix, Vector
from ..... utility import view3d, addon


def invoke(ot, context, event): #????
    bc = context.scene.bc
    ot.last['location'] = bc.shape.matrix_world @ bc.shape.location
    ot.last['view3d_location'] = ot.view3d['location']
    ot.last['lattice'] = bc.lattice.copy()
    ot.last['lattice'].bc.removeable = True
    ot.last['shape'] = bc.shape.copy()
    ot.last['shape'].bc.removeable = True
    ot.last['axis'] = 'XY'


def shape(ot, context, event): #init=False):
    bc = context.scene.bc

    if event.type in {'X', 'Y', 'Z'}:
        if event.value == 'RELEASE':
            ot.last['view3d_location'] = ot.view3d['location']
            if event.type == ot.last['axis']:
                ot.last['axis'] = 'XY'
            else:
                ot.last['axis'] = event.type

    if event.type == 'G': #????
        if event.value == 'RELEASE':
            ot.last['view3d_location'] = ot.view3d['location']

    loc_x = loc_y = loc_z = 0

    if 'X' in ot.last['axis']:
        loc_x = ot.view3d['location'].x - ot.last['view3d_location'].x
    if 'Y' in ot.last['axis']:
        loc_y = ot.view3d['location'].y - ot.last['view3d_location'].y
    if 'Z' in ot.last['axis']:
        loc_z = ot.view3d['location'].z - ot.last['view3d_location'].z

    move_matrix = Matrix.Translation(Vector((loc_x, loc_y, loc_z)))

    if ot.shape_type == 'NGON':
        bc.shape.matrix_world = ot.last['shape'].matrix_world @ move_matrix

    else:
        bc.lattice.matrix_world = ot.last['lattice'].matrix_world @ move_matrix
        bc.shape.matrix_world = ot.last['shape'].matrix_world @ move_matrix
