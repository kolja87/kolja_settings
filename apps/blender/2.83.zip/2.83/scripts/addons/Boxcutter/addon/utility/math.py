from mathutils import Vector


def vector_sum(vectors):
    return sum(vectors, Vector())


def increment_round_xy(increment, x, y, min_limit=False):
    _x = float(x)

    # amount = round(increment, 8)
    # split = str(amount).split('.')[1]
    # length = len(split) if int(split) != 0 else 0
    limit = increment

    # x = round(round(x / amount) * amount, length)
    x = rounded_increment(increment, x)
    if min_limit:
        if _x < 0:
            limit = -increment
        if x == 0:
            x += limit

    # y = round(round(y / amount) * amount, length)
    y = rounded_increment(increment, y)
    if min_limit:
        if y == 0:
            y += limit

    return x, y


def rounded_increment(increment, value, size=8):
    amount = round(increment, size)
    split = str(amount).split('.')[1]
    length = len(split) if amount != 0 else 0

    return round(round(value / amount) * amount, length)
