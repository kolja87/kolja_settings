import os

import bpy

from . import active_tool

name = __name__.partition('.')[0]

icons = {}


class path:


    def __new__(self):
        return os.path.abspath(os.path.join(__file__, '..', '..', '..'))


    def icons():
        return os.path.join(path(), 'icons')


def tool_option():
    option = None

    for tool in bpy.context.workspace.tools:
        if tool.idname == 'BoxCutter' and tool.mode == active_tool().mode:
            option = tool.operator_properties('bc.draw_shape')

    return option


def option():
    option = bpy.context.scene.bc

    return option


def preference():
    preference = bpy.context.preferences.addons[name].preferences

    return preference


def hops():
    wm = bpy.context.window_manager

    if hasattr(wm, 'Hard_Ops_folder_name'):
        return bpy.context.preferences.addons[wm.Hard_Ops_folder_name].preferences

    return False


def kitops():
    wm = bpy.context.window_manager

    if hasattr(wm, 'kitops'):
        return bpy.context.preferences.addons[wm.kitops.addon].preferences

    return False
