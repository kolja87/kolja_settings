from mathutils import Matrix
from ..... utility import view3d, addon
from .... utility import mesh


def invoke(ot, context, event):
    bc = context.scene.bc
    ot.last['mouse'] = ot.mouse['location']
    ot.last['location'] = bc.shape.matrix_world @ bc.shape.location
    ot.last['local_pivot'] = ot.ray['location'] if addon.preference().behavior.set_origin == 'MOUSE' else mesh.set_pivot(ot, context)
    ot.last['global_pivot'] = ot.ray['location'] if addon.preference().behavior.set_origin == 'MOUSE' else bc.shape.matrix_world @ ot.last['local_pivot']
    ot.last['lattice_data'] = bc.lattice.data.copy()
    ot.last['shape_data'] = bc.shape.data.copy()
    ot.last['lattice'] = bc.lattice.copy()
    ot.last['shape'] = bc.shape.copy()
    ot.last['scale'] = (view3d.location3d_to_location2d(ot.last['global_pivot']) - ot.last['mouse']).length
    ot.last['axis'] = 'XYZ'


def shape(ot, context, event):
    bc = context.scene.bc

    scale = ((view3d.location3d_to_location2d(ot.last['global_pivot']) - ot.mouse['location']).length) / ot.last['scale']

    if event.type in {'X', 'Y', 'Z'}:
        if event.value == 'RELEASE':
            if event.type == ot.last['axis']:
                ot.last['axis'] = 'XYZ'
            else:
                ot.last['axis'] = event.type

    scale_x = scale_y = scale_z = 1

    if ot.last['axis'] == 'XYZ':
        scale_x = scale_y = scale_z = scale
    elif ot.last['axis'] == 'X':
        scale_x = scale
    elif ot.last['axis'] == 'Y':
        scale_y = scale
    elif ot.last['axis'] == 'Z':
        scale_z = scale

    scale_matrix = Matrix.Scale(scale_x, 4, (1, 0, 0)) @ Matrix.Scale(scale_y, 4, (0, 1, 0)) @ Matrix.Scale(scale_z, 4, (0, 0, 1))
    ot.last['revert_matrix'] = scale_matrix.inverted()

    if ot.shape_type == 'NGON':

        bc.shape.location = ot.last['local_pivot']
        bc.shape.matrix_world = ot.last['shape'].matrix_world @ scale_matrix
        bc.shape.location = ot.last['global_pivot']

    else:
        points = bc.lattice.data.points

        locked_points = ot.last['lattice_data'].points

        if addon.preference().behavior.set_origin == 'MOUSE':

            bc.lattice.matrix_world = ot.last['lattice'].matrix_world @ scale_matrix
            bc.shape.matrix_world = ot.last['shape'].matrix_world @ scale_matrix

        else:
            for point in (0, 1, 2, 3, 4, 5, 6, 7):
                points[point].co_deform = locked_points[point].co_deform - ot.last['local_pivot']

            bc.shape.location = bc.lattice.location

            for v in range((len(ot.last['shape_data'].vertices))):
                bc.shape.data.vertices[v].co = ot.last['shape_data'].vertices[v].co + ot.last['local_pivot']

            bc.lattice.matrix_world = ot.last['lattice'].matrix_world @ scale_matrix
            bc.shape.matrix_world = ot.last['shape'].matrix_world @ scale_matrix

            bc.shape.location = ot.last['global_pivot']
            bc.lattice.location = ot.last['global_pivot']
