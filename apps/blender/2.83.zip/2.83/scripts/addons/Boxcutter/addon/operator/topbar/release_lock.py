import bpy

from bpy.types import Operator

from ... utility import addon


class BC_OT_release_lock(Operator):
    bl_idname = 'bc.release_lock'
    bl_label = 'INTERNAL'
    bl_description = 'NONE'
    bl_options = {'INTERNAL'}


    def invoke(self, context, event):
        preference = addon.preference()

        if event.ctrl:
            if not preference.keymap.release_lock:
                preference.keymap['release_lock'] = not preference.keymap.release_lock
            preference.behavior.quick_execute = not preference.behavior.quick_execute

        if event.shift:
            if not preference.keymap.release_lock:
                preference.keymap['release_lock'] = not preference.keymap.release_lock
            preference.keymap.release_lock_lazorcut = not preference.keymap.release_lock_lazorcut

        return {'FINISHED'}
