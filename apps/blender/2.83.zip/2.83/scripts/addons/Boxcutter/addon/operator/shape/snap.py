import traceback
import string

from mathutils import Vector

import bpy
from bpy.types import Operator

from .. utility.shader import snap
from ... utility import method_handler, active_tool, addon


class BC_OT_snap(Operator):
    bl_idname = 'bc.snap'
    bl_label = 'Snap'
    bl_description = 'Snap'
    bl_options = {'INTERNAL'}

    clearing: bool = False


    @classmethod
    def poll(cls, context):
        activetool = active_tool().idname == 'BoxCutter'
        snap = addon.preference().snap.enable
        active = context.active_object
        return activetool and snap and ((active and active.type == 'MESH') or not active)


    def invoke(self, context, event):
        return method_handler(invoke,
            arguments = (self, context, event),
            identifier = 'Invoke',
            exit_method = self.exit,
            exit_arguments = (context, ))


    def modal(self, context, event):
        return method_handler(modal,
            arguments = (self, context, event),
            identifier = 'Modal',
            exit_method = self.exit,
            exit_arguments = (context, ))


    def exit(self, context):
        return method_handler(exit,
            arguments=(self, context),
            identifier='Exit')


def invoke(ot, context, event):
    ot.region = bpy.context.region
    ot.key_events = set(string.ascii_uppercase + string.ascii_lowercase + string.digits + string.punctuation)

    ot.snap = snap.setup(context, event)
    ot.cleaning = False

    context.window_manager.modal_handler_add(ot)
    return {'RUNNING_MODAL'}


def modal(ot, context, event):
    preference = addon.preference()

    ot.pass_through = event.type in ot.key_events
    if ot.pass_through or not event.ctrl or ot.cleaning or context.region != ot.region:
        return ot.exit(context)

    ot.snap.update(context, event)

    step = 0
    factor = 10 if preference.snap.increment <= 0.1 else 1
    if ot.snap.grid_active and 'WHEEL' in event.type:
        increment = preference.snap.increment
        direction = event.type[5:-5]

        if round(preference.snap.increment, 2) == 0.25:
            if direction == 'UP':
                preference.snap.increment = 0.2
            else:
                preference.snap.increment = 0.3

            increment = preference.snap.increment

        if increment < 1:
            if increment >= 0.1:
                if direction == 'UP':
                    preference.snap.increment = 0.1 * (increment / 0.1) + 0.1
                elif 0.1 * (increment / 0.1) - 0.1 >= 0.1:
                    preference.snap.increment = 0.1 * (increment / 0.1) - 0.1
                else:
                    preference.snap.increment = 0.09

            else:
                if direction == 'UP':
                    preference.snap.increment = 0.01 * (increment / 0.01) + 0.01
                elif 0.01 * (increment / 0.01) - 0.01 >= 0.01:
                    preference.snap.increment = 0.01 * (increment / 0.01) - 0.01
                else:
                    preference.snap.increment = 0.01

        else:
            if direction == 'UP':
                preference.snap.increment = (increment / 1) + 1

                if preference.snap.increment > 10:
                    preference.snap.increment = 10
            else:
                if (increment / 1) - 1 >= 1:
                    preference.snap.increment = (increment / 1) - 1
                else:
                    preference.snap.increment = 0.9

        if round(preference.snap.increment, 2) == 0.11:
            preference.snap.increment = 0.2

        # preference.snap.increment = float(F'{preference.snap.increment:.2f}')
        ot.report({'INFO'}, F'Grid Size: {preference.snap.increment:.2f}')

        return {'RUNNING_MODAL'}

    return {'PASS_THROUGH'}


def exit(ot, context):
    bc = context.scene.bc
    pass_through = bool(ot.pass_through)
    ot.pass_through = False

    # ot.snap.exit = True
    ot.snap.remove(context)

    bc.snap.hit = False
    bc.snap.location = Vector()

    ot.cleaning = True

    return {'FINISHED' if not ot.snap.handler and not pass_through else 'PASS_THROUGH'}
