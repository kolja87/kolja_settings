import traceback

import bpy
import bmesh

from math import radians

from mathutils import Matrix, Vector

from ... import topbar

from ... utility import addon
# from .. utility import lattice, mesh, shape, modifier
from . shape import modifier
from .. utility import lattice, mesh, shape


# sound effect
# slice lazorcut applies spin
# make box non select turns to cutter
# shift from radial to array (vvv)
# r to rotate (+-swap) array axis
# knife removes materials

# dots toggle (ignores ngon)
# ngon points
# ngon last point snapping

# fix edit mode slice/inset
# knife disable mirror on apply
# text for dots (tooltips)
# text for shape recall
# material cut with all available materials on cutter
# d panel keep open false during modal
# helper to d during modal (draw mode only?)
# mods not applied on slices?
# view align to ortho
# displace operation
# loc, rot, sca operation
# shear, taper
# reverse bevel
# proxy tgt


def create(ot, context, event, custom=None):
    bc = context.scene.bc

    mesh.create.shape(ot, context, event)
    lattice.create(ot, context, event)

    if custom:
        shape.modal.cutter.cycle(ot, context, event, custom=custom)

    bc.empty = bpy.data.objects.new(name=F'{bc.shape.name} Array Target', object_data=None)
    bc.collection.objects.link(bc.empty)
    bc.empty.empty_display_type = 'SINGLE_ARROW'
    bc.empty.parent = bc.shape
    bc.empty.hide_set(True)


def clean(ot, context, all=False):
    preference = addon.preference()
    bc = bpy.context.scene.bc
    type_to_custom = False

    # if ot.auto_ortho and ot.align_to_view:
    #     bpy.ops.view3d.view_persportho('INVOKE_DEFAULT')

    for obj in context.selected_objects:
        obj.select_set(False)

    bc.shape.hide_set(False)
    bc.lattice.hide_set(False)

    context.view_layer.objects.active = bc.shape
    bc.shape.select_set(True)

    bpy.ops.object.mode_set(mode='EDIT')
    context.view_layer.update()
    bpy.ops.object.mode_set(mode='OBJECT')

    if ot.wires_displayed:
        context.space_data.overlay.show_wireframes = False

    if not ot.live and ot.mode in {'CUT', 'SLICE', 'INSET', 'JOIN', 'EXTRACT'}:
        modifier.create.boolean(ot, show=True)

    for mod in bc.shape.modifiers:
        mod.show_viewport = True

        if mod.type == 'BEVEL':
            preference.shape['bevel_segments'] = mod.segments

    for obj in ot.datablock['targets']:
        for mod in obj.modifiers:
            if mod.type == 'BOOLEAN':
                mod.show_viewport = True

    for obj in ot.datablock['slices']:
        for mod in obj.modifiers:
            if mod.type == 'BOOLEAN':
                mod.show_viewport = True

    keep_types = [type for type in ('BEVEL', 'SOLIDIFY', 'ARRAY', 'MIRROR', 'SCREW', 'LATTICE') if getattr(preference.behavior, F'keep_{type.lower()}')] if preference.behavior.keep_modifiers else []
    keep_types.append('DISPLACE')
    keep_types.append('DECIMATE')

    if bpy.app.version[1] >= 82:
        keep_types.append('WELD')

    modifier.apply(bc.shape, ignore=[mod for mod in bc.shape.modifiers if mod.type in keep_types])

    if ot.shape_type == 'CIRCLE' and not preference.behavior.keep_screw:
        for mod in bc.shape.modifiers:
            if mod.type == 'DECIMATE':
                bc.shape.modifiers.remove(mod)

        bm = bmesh.new()
        bm.from_mesh(bc.shape.data)

        bmesh.ops.dissolve_limit(bm, angle_limit=0.01, use_dissolve_boundaries=True, verts=bm.verts, edges=bm.edges)
        bmesh.ops.dissolve_limit(bm, angle_limit=0.01, use_dissolve_boundaries=True, verts=bm.verts, edges=bm.edges)

        bm.to_mesh(bc.shape.data)
        bm.free()

        indices = []
        for vert in bc.shape.data.vertices:
            index = 5 if not ot.flip_z else 1
            # if ot.mode == 'JOIN' and not ot.flip_z or ot.mode != 'JOIN' and ot.flip_z:
                # index = 1

            if round(vert.co.z, 5) == round(bc.lattice.data.points[index].co_deform.z, 5):
                indices.append(vert.index)

        if len(bc.shape.vertex_groups) and len(indices):
            bc.shape.vertex_groups[0].add(index=indices, weight=1.0, type='ADD')

    if ot.lazorcut:
        if ot.mode not in {'MAKE', 'KNIFE'} and ot.original_mode == 'EDIT_MESH':
            modifier.update(ot, bpy.context)

        elif ot.mode == 'KNIFE':
            # if not ot.align_to_view:
            if preference.surface != 'VIEW':
                ot.extruded = True
                mesh.knife(ot, bpy.context, None)

            elif not all:
                all = True

                modifier.apply(bc.shape)

                bpy.ops.object.mode_set(mode='EDIT')

                original_selection_mode = tuple(bpy.context.tool_settings.mesh_select_mode)

                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.remove_doubles(threshold=0.0006)

                bpy.ops.object.mode_set(mode='OBJECT')

                for obj in ot.datablock['targets']:
                    context.view_layer.objects.active = obj
                    obj.select_set(True)

                    context.view_layer.update()

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.mesh.knife_project(cut_through=True)
                    bpy.ops.object.mode_set(mode='OBJECT')

                    if addon.hops() and addon.preference().behavior.hops_mark:
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.context.scene.tool_settings.mesh_select_mode = (False, True, False)
                        bpy.ops.mesh.region_to_loop()
                        bpy.ops.object.mode_set(mode='OBJECT')

                        pref = addon.hops().property

                        for edge in obj.data.edges:
                            if not edge.select:
                                continue

                            edge.crease = float(pref.sharp_use_crease)
                            edge.use_seam = float(pref.sharp_use_seam)
                            edge.bevel_weight = float(pref.sharp_use_bweight)
                            edge.use_edge_sharp = float(pref.sharp_use_sharp)

                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.mesh.loop_to_region()

                        bpy.context.tool_settings.mesh_select_mode = original_selection_mode

                    bpy.ops.object.mode_set(mode='OBJECT')

                    obj.select_set(False)

                context.view_layer.objects.active = bc.shape

                if ot.original_mode == 'EDIT_MESH':
                    bpy.ops.object.mode_set(mode='EDIT')

                    bpy.context.tool_settings.mesh_select_mode = original_selection_mode

        elif ot.mode == 'MAKE':
            bpy.ops.object.mode_set(mode='EDIT')

            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.normals_make_consistent()

            bpy.ops.object.mode_set(mode='OBJECT')

    shape.modal.bevel_modifiers = list()

    if not all:
        if ot.mode == 'EXTRACT':
            type_to_custom = True
            for obj in ot.datablock['targets']:
                for mod in obj.modifiers:
                    if mod.type == 'BOOLEAN' and mod.object == bc.shape:
                        obj.modifiers.remove(mod)

            slice_duplicates = []
            for obj in ot.datablock['slices']:

                for mod in obj.modifiers:
                    if mod.type in {'BEVEL', 'MIRROR'}:
                        obj.modifiers.remove(mod)

                bpy.context.view_layer.update()

                new = obj.copy()
                slice_duplicates.append(new)
                obj.data = obj.data.copy()

                bc.collection.objects.link(new)

                # modifier.apply(obj, hard_apply=False)
                modifier.apply(obj)

            for obj in slice_duplicates:
                for mod in obj.modifiers:
                    if mod.type == 'BOOLEAN' and mod.operation != 'INTERSECT':
                        obj.modifiers.remove(mod)

            for obj in slice_duplicates:
                # modifier.apply(obj, hard_apply=False)
                modifier.apply(obj)

            for obj in slice_duplicates:
                center = 0.125 * sum((obj.matrix_world @ Vector(bound) for bound in obj.bound_box), Vector())
                obj.location = center
                obj.data.transform(Matrix.Translation(-center))
                obj.data.transform(Matrix.Scale(0.998, 4, Vector((-1, 0, 0)) ) )
                obj.data.transform(Matrix.Scale(0.998, 4, Vector((0, -1, 0)) ) )
                obj.data.transform(Matrix.Scale(0.998, 4, Vector((0, 0, -1)) ) )

            me = bpy.data.meshes.new(name='Extraction')

            bm = bmesh.new()

            for obj in slice_duplicates:
                obj.data.transform(Matrix.Translation(obj.location))
                bm.from_mesh(obj.data)

            bm.to_mesh(me)
            bm.free()

            for obj in slice_duplicates:
                bpy.data.objects.remove(obj)

            obj = bpy.data.objects.new(name='Extraction', object_data=me)
            bc.collection.objects.link(obj)

            for face in obj.data.polygons:
                face.use_smooth = True

            obj.data.use_auto_smooth = True
            obj.data.auto_smooth_angle = radians(15)
            obj.data.use_customdata_vertex_bevel = True
            obj.data.use_customdata_edge_bevel = True
            obj.data.use_customdata_edge_crease = True

            for slice in ot.datablock['slices']:
                mod = obj.modifiers.new(name='Boolean', type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
                mod.object = slice

            # modifier.apply(obj, hard_apply=False)
            modifier.apply(obj)

            bpy.context.view_layer.update()

            if sum(obj.dimensions) > 0.001:
                bc.stored_shape = obj
                obj.data.transform(bc.shape.matrix_world.inverted())
                obj.location = Vector((0, 0, 0))

                bpy.context.view_layer.update()

                center = 0.125 * sum((obj.matrix_world @ Vector(bound) for bound in obj.bound_box), Vector())
                obj.location = center
                obj.data.transform(Matrix.Translation(-center))

                obj.location = Vector((0, 0, 0))

            else:
                bpy.data.objects.remove(obj)

            obj.hide_set(True)

            bpy.data.objects.remove(bc.shape)
            bc.shape = None

            for obj in ot.datablock['slices']:
                bpy.data.objects.remove(obj)

            if bc.original_active:
                bpy.context.view_layer.objects.active = bc.original_active

            for obj in ot.original_selected:
                obj.select_set(True)

        elif ot.mode != 'KNIFE':
            if ot.mode != 'MAKE':
                if ot.original_mode != 'EDIT_MESH':
                    if ot.shape_type in {'CIRCLE', 'NGON'}:
                        bc.shape.hide_set(False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        original_selection_mode = tuple(bpy.context.tool_settings.mesh_select_mode)
                        bpy.context.tool_settings.mesh_select_mode = (True, False, False)
                        bpy.ops.mesh.select_all(action='SELECT')
                        bpy.ops.mesh.remove_doubles(threshold=0.0006)

                        if bc.cyclic or ot.shape_type == 'CIRCLE':
                            bpy.ops.mesh.normals_make_consistent(inside=False)

                        # bpy.ops.mesh.dissolve_limited(angle_limit=0.008, use_dissolve_boundaries=False, delimit={'NORMAL'})
                        bpy.context.tool_settings.mesh_select_mode = original_selection_mode
                        bpy.ops.object.mode_set(mode='OBJECT')

                        # bpy.context.view_layer.update()

                    if ot.behavior != 'DESTRUCTIVE':
                        bc.shape.bc.applied = True

            else:
                # TODO: if in edit mode join made geo with active object
                bc.collection.objects.unlink(bc.shape)

                if bc.original_active and bc.original_active.users_collection:
                    for collection in bc.original_active.users_collection:
                        collection.objects.link(bc.shape)
                else:
                    bpy.context.scene.collection.objects.link(bc.shape)

                bpy.context.view_layer.objects.active = bc.shape

                if ot.shape_type in {'CIRCLE', 'NGON'}:
                    bpy.ops.object.mode_set(mode='EDIT')
                    original_selection_mode = tuple(bpy.context.tool_settings.mesh_select_mode)
                    bpy.context.tool_settings.mesh_select_mode = (True, False, False)
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.remove_doubles(threshold=0.0006)
                    bpy.ops.mesh.normals_make_consistent(inside=False)
                    # bpy.ops.mesh.dissolve_limited(angle_limit=0.008, use_dissolve_boundaries=False, delimit={'NORMAL'})
                    bpy.context.tool_settings.mesh_select_mode = original_selection_mode
                    bpy.ops.object.mode_set(mode='OBJECT')

                    # bpy.context.view_layer.update()

                bc.shape.name = ot.shape_type.title()
                bc.shape.data.name = ot.shape_type.title()
                bc.shape.bc.applied = True
                bc.shape.hide_render = False
                bc.shape.hide_set(False)

                if hasattr(bc.shape, 'cycles_visibility'):
                    bc.shape.cycles_visibility.camera = True
                    bc.shape.cycles_visibility.diffuse = True
                    bc.shape.cycles_visibility.glossy = True
                    bc.shape.cycles_visibility.transmission = True
                    bc.shape.cycles_visibility.scatter = True
                    bc.shape.cycles_visibility.shadow = True

            if ot.show_shape:
                bc.shape.hide_set(False)

                if (not preference.behavior.make_active and ot.datablock['targets']) or (not ot.shift and ot.datablock['targets']):
                    bpy.context.view_layer.objects.active = bc.original_active
                    bc.original_active.select_set(True)
                    bc.shape.select_set(False)

                else:
                    bc.shape.select_set(ot.mode != 'INSET')

                    for obj in bpy.context.visible_objects:
                        if obj != bc.shape:
                            obj.select_set(False)
                        elif not bc.original_active:
                            bpy.context.view_layer.objects.active = obj
                            obj.select_set(True)

                    if ot.mode == 'INSET':
                        bc.inset.hide_set(False)
                        bc.inset.select_set(True)
                        bpy.context.view_layer.objects.active = bc.inset

                if ot.original_mode == 'EDIT_MESH' and ot.datablock['targets']:
                    for pair in zip(ot.datablock['targets'], ot.datablock['overrides']):
                        obj = pair[0]
                        override = pair[1]

                        bpy.context.view_layer.objects.active = obj
                        name = obj.data.name
                        obj.data.name = 'tmp'

                        obj.data = override
                        obj.data.name = name

                    bpy.context.view_layer.objects.active = bc.shape

                    ot.datablock['overrides'] = list()
            else:
                if ot.mode != 'MAKE':
                    bc.shape.hide_set(True)

                    if ot.mode == 'INSET':
                        bc.shape.select_set(False)

                        for obj in ot.datablock['slices']:
                            obj.hide_set(True)

                    if ot.original_mode == 'EDIT_MESH':
                        for obj in ot.datablock['slices']:
                            obj.select_set(True)

                if ot.datablock['targets']:
                    bpy.context.view_layer.objects.active = bc.original_active
                    bc.original_active.select_set(True)

                    bpy.ops.object.mode_set(mode='OBJECT')

                    for obj in ot.original_selected:
                        obj.select_set(True)

                    if ot.behavior == 'DESTRUCTIVE' and ot.original_mode != 'EDIT_MESH':
                        for obj in ot.datablock['targets']:
                            for mod in obj.modifiers:
                                if ot.mode == 'INSET' and mod.type == 'BOOLEAN' and mod.object == bc.shape:
                                    obj.modifiers.remove(mod)

                        for obj in ot.datablock['targets']:
                            modifier.apply(obj, mod=modifier.shape_bool(ot, obj))

                            if ot.mode == 'INSET':
                                for mod in obj.modifiers:
                                    if mod.type == 'BOOLEAN' and mod.object in ot.datablock['slices']:
                                        modifier.apply(obj, mod=mod)

                        for obj in ot.datablock['slices']:
                            # modifier.apply(obj, mod=modifier.shape_bool(ot, obj), hard_apply=False)
                            modifier.apply(obj, mod=modifier.shape_bool(ot, obj))

                        # bpy.data.objects.remove(bc.shape)

                        for obj in ot.datablock['slices']:
                            if ot.mode == 'INSET':
                                bpy.data.objects.remove(obj)
                            else:
                                obj.select_set(True)

                    elif ot.mode == 'SLICE' and (preference.behavior.apply_slices or ot.original_mode == 'EDIT_MESH'):

                        for obj in ot.datablock['slices']:

                            bvls = [mod for mod in obj.modifiers if mod.type == 'BEVEL'][-1:]
                            wns = [mod for mod in obj.modifiers if mod.type == 'WEIGHTED_NORMAL']
                            ignore = bvls + wns

                            modifier.apply(obj, ignore=ignore)
                            obj.select_set(True)

                            bvl = [mod for mod in obj.modifiers if mod.type == 'BEVEL'][-1:]
                            wn = [mod for mod in obj.modifiers if mod.type == 'WEIGHTED_NORMAL'][-1:]

                            if bvl and True not in [d < 0.0001 for d in obj.dimensions]:
                                bvl[0].use_only_vertices = False

                            for mod in obj.modifiers:
                                if (not bvl or mod != bvl[0]) and (not wn or mod != wn[0]):
                                    obj.modifiers.remove(mod)

                    elif ot.mode == 'SLICE':
                        for obj in ot.datablock['slices']:
                            obj.select_set(True)

                    if ot.original_mode == 'EDIT_MESH':
                        for obj in ot.datablock['targets']:
                            for mod in obj.modifiers:
                                if mod.type == 'BOOLEAN':
                                    if mod.object == bc.shape or mod.object in ot.datablock['slices']:
                                        obj.modifiers.remove(mod)

                            bpy.ops.object.mode_set(mode='EDIT')

            if ot.mode == 'INSET':
                for obj in ot.datablock['targets']:
                    for mod in obj.modifiers:
                        if mod.type == 'BOOLEAN' and mod.object == bc.shape:
                            obj.modifiers.remove(mod)

            if hasattr(bc.shape, 'hops'):
                bc.shape.hops.status = 'BOOLSHAPE' if ot.mode != 'MAKE' else 'UNDEFINED'

        else:
            bpy.data.objects.remove(bc.shape)
            bc.shape = None

            bpy.context.view_layer.objects.active = bc.original_active
            bc.original_active.select_set(True)

            for obj in ot.original_selected:
                obj.select_set(True)

            if ot.original_mode == 'EDIT_MESH':
                bpy.ops.object.mode_set(mode='EDIT')

        if not preference.behavior.keep_lattice:
            bpy.data.objects.remove(bc.lattice)

        else:
            bc.lattice.data.bc.removeable = False
            bc.lattice.hide_set(not ot.show_shape)

        bpy.data.objects.remove(ot.datablock['plane'])

        for me in bpy.data.meshes:
            if me.bc.removeable:
                bpy.data.meshes.remove(me)

        for lat in bpy.data.lattices:
            if lat.bc.removeable:
                bpy.data.lattices.remove(lat)

        array = None

        if bc.shape:

            for mod in bc.shape.modifiers:
                if mod.type == 'ARRAY':
                    array = mod

                    break

            if array and array.use_object_offset:

                bc.empty.driver_remove('rotation_euler', 2)
                driver = bc.empty.driver_add('rotation_euler', 2).driver
                driver.type == 'SCRIPTED'

                count = driver.variables.new()
                count.name = 'count'
                count.targets[0].id_type = 'OBJECT'
                count.targets[0].id = bc.shape
                count.targets[0].data_path = F'modifiers["{array.name}"].count'

                driver.expression = 'radians(360 / count)'

            else:
                bpy.data.objects.remove(bc.empty)
                bc.empty = None

        else:
            bpy.data.objects.remove(bc.empty)
            bc.empty = None

    else:
        if bc.original_active:
            bpy.ops.object.mode_set(mode='OBJECT')
            try:
                bpy.context.view_layer.objects.active = bc.original_active
                bc.original_active.select_set(True)

                if ot.cancelled:
                    if ot.datablock['overrides']:
                        for pair in zip(ot.datablock['targets'], ot.datablock['overrides']):
                            obj = pair[0]
                            override = pair[1]

                            name = obj.data.name
                            obj.data.name = 'tmp'

                            obj.data = override
                            obj.data.name = name

                            for mod in obj.modifiers:
                                mod.show_viewport = True

                        ot.datablock['overrides'] = list()
            except:
                traceback.print_exc()

        for obj in bc.shape.children:
            if obj.data:
                obj.data.bc.removeable = True

            bpy.data.objects.remove(obj)

        bpy.data.objects.remove(bc.shape)
        bpy.data.objects.remove(bc.lattice)

        for obj in ot.datablock['slices']:
            bpy.data.objects.remove(obj)

        for obj in ot.datablock['targets']:
            for mod in obj.modifiers:
                if mod.type == 'BOOLEAN' and not mod.object:

                    obj.modifiers.remove(mod)

        if ot.original_mode == 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='EDIT')

    for me in bpy.data.meshes:
        if me.bc.removeable:
            bpy.data.meshes.remove(me)

    for lat in bpy.data.lattices:
        if lat.bc.removeable:
            bpy.data.lattices.remove(lat)

    bc.lattice = None

    for obj in bpy.data.objects:
        for mod in obj.modifiers:
            if mod.type == 'BOOLEAN' and mod.object == bc.shape and ot.mode == 'MAKE':
                obj.modifiers.remove(mod)

            elif mod.type == 'BOOLEAN' and not mod.object:
                obj.modifiers.remove(mod)

        applied_cycle = (obj.bc.shape and obj.bc.shape != bc.shape and obj.bc.applied_cycle)
        if (obj.type == 'MESH' and obj.data.bc.removeable) or obj.users == 0 or applied_cycle:
            bpy.data.objects.remove(obj)

        elif obj.bc.shape and obj.bc.applied_cycle:
            obj.bc.applied = True
            obj.bc.applied_cycle = False

    # bc.shape = None if not bc.stored_shape else bc.stored_shape

    # Stuff done after modifiers apply: Pivot point setup, parenting shapes setup
    # TODO: Should not happen in clean
    mesh.set_pivot(bc, context)

    if bc.original_active and preference.behavior.parent_shape:
        if bc.shape:
            bc.shape.parent = bc.original_active
            bc.shape.matrix_world = bc.shape.matrix_basis
        if bc.inset:
            bc.inset.parent = bc.original_active
            bc.inset.matrix_world = bc.inset.matrix_basis
        if bc.slice:
            bc.slice.parent = bc.original_active
            bc.slice.matrix_world = bc.slice.matrix_basis

    bc.slice = None
    bc.inset = None
    bc.plane = None
    bc.location = Vector()

    bc.snap.display = True

    for me in bpy.data.meshes:
        if me.users == 0:
            bpy.data.meshes.remove(me)

    if preference.surface != ot.last['surface']:
        preference.surface = ot.last['surface']

    if ot.behavior == 'DESTRUCTIVE' and ot.mode != 'MAKE' and bc.shape and not ot.show_shape:
        bpy.data.meshes.remove(bc.shape.data)

    if 'Cutters' in bpy.data.collections and not bc.collection.objects:
        bpy.data.collections.remove(bc.collection)

    if type_to_custom:
        topbar.change_prop(bpy.context, 'shape_type', 'CUSTOM')

    if ot.mode != 'KNIFE':
        topbar.change_prop(bpy.context, 'mode', ot.last['start_mode'] if not type_to_custom else 'CUT')
    elif preference.behavior.hops_mark:
        preference.behavior.hops_mark = False

    if preference.behavior.recut:
        preference.behavior.recut = False

    topbar.change_prop(bpy.context, 'operation', ot.last['start_operation'])

    if not ot.datablock['targets'] and ot.mode == 'MAKE':
        if bc.shape:
            bc.shape.select_set(False)
        context.view_layer.objects.active = None

    del ot.tool
    ot.original_selected = []
    ot.original_visible = []
    ot.material = ''
    del ot.datablock
    del ot.last
    del ot.ray
    del ot.start
    del ot.geo
    del ot.mouse
    del ot.view3d
    del ot.existing

    bc.shape = None if not bc.stored_shape else bc.stored_shape

    shape.modal.cutter.clear_sum()

    if ot.snap:
        ot.snap = False

        # bpy.ops.bc.snap('INVOKE_DEFAULT')
