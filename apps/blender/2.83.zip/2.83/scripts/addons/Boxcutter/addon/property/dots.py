import bpy

from bpy.types import PropertyGroup
from bpy.props import *


class Dots(PropertyGroup):
    enable: BoolProperty()

    color: FloatVectorProperty(size=4)
    alpha: FloatProperty()
    highlight: BoolProperty()

    active: BoolProperty()
    location: FloatVectorProperty()
    location2d: FloatVectorProperty(size=2)

    index: IntProperty(default=-1)

    type: StringProperty()


class Groups(PropertyGroup):
    enable: BoolProperty()
    dot: CollectionProperty(type=Dots)


class option(PropertyGroup):
    enable: BoolProperty()
    groups: CollectionProperty(type=Groups)
    # active: PointerProperty(type=Dots)
    active: StringProperty()
