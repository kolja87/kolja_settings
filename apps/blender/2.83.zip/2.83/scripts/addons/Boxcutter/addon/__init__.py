from . import icon, operator, panel, property, keymap, pie, topbar


def register():
    property.preference.register()
    property.register()

    operator.register()
    panel.register()
    pie.register()
    topbar.register()

    keymap.register()


def unregister():
    keymap.unregister()

    topbar.unregister()
    pie.unregister()
    panel.unregister()
    operator.unregister()

    property.unregister()
    property.preference.unregister()
