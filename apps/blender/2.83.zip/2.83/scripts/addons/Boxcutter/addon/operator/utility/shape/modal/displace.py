import bpy

from math import radians

# from .... utility import modifier
from .. import modifier
from ..... utility import addon, screen


def shape(ot, context, event):
    bc = context.scene.bc

    displace = None

    for mod in bc.shape.modifiers:
        if mod.type == 'DISPLACE':
            displace = mod

            break

    if not displace:
        displace = bc.shape.modifiers.new('Displace', 'DISPLACE')
        displace.direction = 'X'

    location = ot.view3d['location'].x + ot.start['displace']

    displace.strength = location
    ot.last['modifier']['displace'] = displace.strength
