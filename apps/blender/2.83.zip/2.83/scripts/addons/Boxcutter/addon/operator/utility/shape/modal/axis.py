from ..... import topbar


def change(ot, context, to='NONE'):
    bc = context.scene.bc
    value = to

    bc.axis = value
