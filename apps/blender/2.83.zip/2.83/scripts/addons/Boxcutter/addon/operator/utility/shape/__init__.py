import bpy
import bmesh

from mathutils import Matrix, Vector, Euler

from . import modal, modifier, change
from .. import mesh
# from .. import lattice, modifier
from .. import lattice
from .... utility import addon, object


def lazorcut(ot, context):
    preference = addon.preference()
    bc = context.scene.bc
    boolean = False

    if ot.mode == 'KNIFE' and preference.surface == 'VIEW':
        return

    if ot.mode == 'MAKE':
        bc.shape.display_type = 'TEXTURED'

    for obj in ot.datablock['targets']:
        for mod in reversed(obj.modifiers[:]):
            if mod.type == 'BOOLEAN' and mod.object == bc.shape:
                boolean = True
                mod.show_viewport = True

    if ot.datablock['targets']:
        init_point_positions(ot, bc, context)

    else:
        init_point_positions(ot, bc, context, depth=preference.shape.lazorcut_depth)

        return

    ot.lazorcut = True

    if not boolean:
        modifier.create.boolean(ot, show=True)

    alignment = ot.start['alignment']
    if not preference.behavior.lazorcut_trim or not alignment or not ot.datablock['targets']:
        return

    objects = [obj.copy() for obj in ot.datablock['targets'] if obj.type == 'MESH']

    for obj in objects:
        context.scene.collection.objects.link(obj)

    context.view_layer.update()

    for obj in objects:
        obj.data = obj.data.copy()

        for mod in obj.modifiers:
            if mod.type == 'BOOLEAN' and mod.object and mod.object == bc.shape:
                obj.modifiers.remove(mod)

            elif not mod.show_viewport:
                mod.show_viewport = True

        # modifier.apply(obj, hard_apply=False)
        modifier.apply(obj)

    mesh = bpy.data.meshes.new(name='TMP')
    bm = bmesh.new()

    # for o, obj in zip(ot.datablock['targets'], objects):
    #     obj.matrix_world = o.matrix_world

    # context.view_layer.update()

    for obj in objects:
        obj.data.transform(obj.matrix_world)
        bm.from_mesh(obj.data)
        # obj.location = Vector()

        bpy.data.objects.remove(obj)

    del objects

    bm.to_mesh(mesh)
    bm.free()

    obj = bpy.data.objects.new(name='TMP', object_data=mesh)
    obj.display_type = 'WIRE'
    context.scene.collection.objects.link(obj)
    obj.bc.removeable = True
    obj.data.bc.removeable = True

    # mod = obj.modifiers.new(name='TMP', type='DISPLACE')
    # mod.mid_level = 0
    # mod.strength = preference.shape.offset

    mod = obj.modifiers.new(name='TMP', type='BOOLEAN')
    mod.operation = 'INTERSECT'
    mod.object = bc.shape

    obj.matrix_world = bc.shape.matrix_world
    obj.data.transform(bc.shape.matrix_world.inverted())

    context.view_layer.update()

    if obj.dimensions[2] < 0.001:
        return

    # aligned = ot.mode == 'KNIFE' and ot.align_to_view
    depth = preference.shape.lazorcut_depth + preference.shape.offset
    for point in lattice.back:
        bc.lattice.data.points[point].co_deform.z = -(obj.dimensions[2] + (preference.shape.offset + 0.01) if not preference.shape.lazorcut_depth else depth)

    if ot.shape_type == 'NGON':
        if not ot.extruded:
            mesh.extrude(ot, context, None)

        verts = [vert for vert in bc.shape.data.vertices[:] if vert.index in ot.geo['indices']['extrusion']]

        for vert in verts:
            vert.co.z = -(obj.dimensions[2] + (preference.shape.offset + 0.01) if not preference.shape.lazorcut_depth else depth)

    front = (1, 2, 5, 6)

    # matrix = bc.shape.matrix_world.inverted()
    location = (0.25 * sum((Vector(bc.shape.bound_box[point][:]) for point in front), Vector()))
    location_to = (0.25 * sum((Vector(obj.bound_box[point][:]) for point in front), Vector()))
    difference = (location - location_to)
    difference.z -= preference.shape.offset

    current = bc.shape.location
    location = Vector((0, 0, -difference.z)) @ bc.shape.matrix_world.inverted()

    # for point in (0, 1, 2, 3, 4, 5, 6, 7):
    #     bc.lattice.data.points[point].co_deform = bc.lattice.data.points[point].co_deform + location
    bc.lattice.location = current + location
    bc.shape.location = current + location

    context.view_layer.update()

    ot.start['matrix'] = bc.shape.matrix_world.copy()

    obj.data.bc.removeable = True
    bpy.data.objects.remove(obj)

    del obj

    ot.lazorcut_performed = True
    ot.start['offset'] = bc.lattice.data.points[1].co_deform.z
    ot.start['extrude'] = bc.lattice.data.points[5].co_deform.z


def init_point_positions(ot, bc, context, depth=None):
    aligned = ot.mode == 'KNIFE' and ot.align_to_view
    if ot.shape_type != 'NGON':
        for point in lattice.back:
            if context.active_object:
                bc.lattice.data.points[point].co_deform.z -= max(dimension for dimension in context.active_object.dimensions[:]) * 8 if addon.preference().behavior.lazorcut_trim else 1.75
            elif depth:
                if ot.mode != 'MAKE':
                    bc.lattice.data.points[point].co_deform.z -= depth
                else:
                    bc.lattice.data.points[point].co_deform.z += depth
            else:
                if ot.mode != 'MAKE':
                    bc.lattice.data.points[point].co_deform.z -= 0.5
                else:
                    bc.lattice.data.points[point].co_deform.z += 0.5

    elif not aligned:
        if not ot.extruded:
            # modal.extrude.shape(ot, context, None)
            mesh.extrude(ot, context, None)

        verts = [vert for vert in bc.shape.data.vertices[:] if vert.index in ot.geo['indices']['extrusion']]

        for vert in verts:
            if bc.original_active:
                vert.co.z -= max(dimension for dimension in context.active_object.dimensions[:]) * 8 if addon.preference().behavior.lazorcut_trim else 1.75
            elif depth:
                if ot.mode != 'MAKE':
                    vert.co.z -= depth
                else:
                    vert.co.z += depth
            else:
                if ot.mode != 'MAKE':
                    vert.co.z -= 0.5
                else:
                    vert.co.z += 0.5
