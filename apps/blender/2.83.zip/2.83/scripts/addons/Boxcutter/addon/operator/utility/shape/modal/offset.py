from ..... import topbar

from .... utility import lattice, mesh


def shape(ot, context, event):
    ngon = ot.shape_type == 'NGON'

    if ot.shape_type == 'NGON':
        if not ot.extruded:
            mesh.extrude(ot, context, event)

    if not ngon:
        lattice.offset(ot, context, event)
    else:
        mesh.offset(ot, context, event)
