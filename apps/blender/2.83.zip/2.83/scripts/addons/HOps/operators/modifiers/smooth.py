import bpy, bmesh, gpu
from bgl import *
from gpu_extras.batch import batch_for_shader
from ... graphics.drawing2d import draw_text, set_drawing_dpi, draw_box
from ... utils.blender_ui import get_dpi, get_dpi_factor
from ... preferences import get_preferences
from ... utility import modifier
from ... addon.utility import method_handler


class HOPS_OT_MOD_Smooth(bpy.types.Operator):
    bl_idname = "hops.mod_smooth"
    bl_label = "Adjust Smooth Modifier"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING', 'GRAB_CURSOR'}
    bl_description = """
LMB - Adjust Smooth Modifier
LMB + Ctrl - Create new Smooth Modifier
LMB + Shift - Auto Vertex Group

Press H for help
"""

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode == 'OBJECT'


    def invoke(self, context, event):
        self.create_new = event.ctrl
        self.auto_vgroup = event.shift

        self.modal_scale = get_preferences().ui.Hops_modal_scale
        self.obj = context.active_object
        self.mods = [m for m in self.obj.modifiers if m.type == 'SMOOTH']

        if not self.mods:
            self.create_new = True

        if self.create_new:
            self.mod = self.obj.modifiers.new("Smooth", 'SMOOTH')
            self.mods.append(self.mod)

        else:
            self.mod = self.mods[-1]

        self.values = {m:{} for m in self.mods}
        for mod in self.mods:
            self.store(mod)

        if self.auto_vgroup:
            self.create_vgroup()

        self.buffer = self.mod.factor

        self.mouse_prev_x = event.mouse_region_x
        self.mouse_start_x = event.mouse_region_x
        self.mouse_start_y = event.mouse_region_y

        self.draw_handler = bpy.types.SpaceView3D.draw_handler_add(self.draw_ui, (context, ), "WINDOW", "POST_PIXEL")

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


    def modal(self, context, event):
        if event.type == 'MIDDLEMOUSE':
            return {'PASS_THROUGH'}

        elif event.type == 'Z' and (event.shift or event.alt):
            return {'PASS_THROUGH'}

        elif event.type in ('LEFTMOUSE', 'SPACE'):
            # bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
            self.remove_ui()
            context.area.header_text_set(text=None)
            self.report({'INFO'}, "Finished")
            return {'FINISHED'}

        elif event.type in ('RIGHTMOUSE', 'ESC'):
            # bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
            self.remove_ui()
            context.area.header_text_set(text=None)
            self.report({'INFO'}, "Cancelled")
            self.cancel(context)
            return {'CANCELLED'}

        elif event.type in ('WHEELDOWNMOUSE', 'WHEELUPMOUSE') and event.shift:
            if event.type == 'WHEELDOWNMOUSE':
                self.scroll(1)
            elif event.type == 'WHEELUPMOUSE':
                self.scroll(-1)
            self.buffer = self.mod.factor

        elif event.type == 'MOUSEMOVE':
            divisor = self.modal_scale * (10000 if event.shift else 1000)
            offset = event.mouse_region_x - self.mouse_prev_x
            self.buffer -= offset / divisor / get_dpi_factor()
            self.buffer = max(self.buffer, 0)
            digits = 2 if event.ctrl and event.shift else 1 if event.ctrl else 3
            self.mod.factor = round(self.buffer, digits)

        elif event.type in ('WHEELDOWNMOUSE', 'WHEELUPMOUSE'):
            if event.type == 'WHEELDOWNMOUSE':
                self.mod.iterations -= 1
            elif event.type == 'WHEELUPMOUSE':
                self.mod.iterations += 1
            self.mod.iterations = max(self.mod.iterations, 0)

        elif event.type in ('X', 'Y', 'Z') and event.ctrl:
            if event.type == 'X' and event.value == 'PRESS':
                self.mod.use_x = not self.mod.use_x
            elif event.type == 'Y' and event.value == 'PRESS':
                self.mod.use_y = not self.mod.use_y
            elif event.type == 'Z' and event.value == 'PRESS':
                self.mod.use_z = not self.mod.use_z

        elif event.type in ('X', 'Y', 'Z'):
            if event.type == 'X' and event.value == 'PRESS':
                self.mod.use_x = True
                self.mod.use_y = False
                self.mod.use_z = False
            elif event.type == 'Y' and event.value == 'PRESS':
                self.mod.use_x = False
                self.mod.use_y = True
                self.mod.use_z = False
            elif event.type == 'Z' and event.value == 'PRESS':
                self.mod.use_x = False
                self.mod.use_y = False
                self.mod.use_z = True

        if event.type == "H" and event.value == "PRESS":
            get_preferences().property.hops_modal_help = not get_preferences().property.hops_modal_help
            context.area.tag_redraw()

        self.mouse_prev_x = event.mouse_region_x

        return {'RUNNING_MODAL'}


    def cancel(self, context):
        for mod in self.mods:
            self.reset(mod)

        if self.create_new:
            self.obj.modifiers.remove(self.mods[-1])


    def scroll(self, direction):
        index = self.mods.index(self.mod)
        index = (index + direction) % len(self.mods)
        self.mod = self.mods[index]


    def store(self, mod):
        self.values[mod]["factor"] = mod.factor
        self.values[mod]["iterations"] = mod.iterations
        self.values[mod]["use_x"] = mod.use_x
        self.values[mod]["use_y"] = mod.use_y
        self.values[mod]["use_z"] = mod.use_z


    def reset(self, mod):
        mod.factor = self.values[mod]["factor"]
        mod.iterations = self.values[mod]["iterations"]
        mod.use_x = self.values[mod]["use_x"]
        mod.use_y = self.values[mod]["use_y"]
        mod.use_z = self.values[mod]["use_z"]


    def create_vgroup(self):
        vertex_group = None

        for group in self.obj.vertex_groups:
            if group.name == "HOPS_Smooth":
                vertex_group = group

        if not vertex_group:
            vertex_group = self.obj.vertex_groups.new(name="HOPS_Smooth")

        verts = list(range(len(self.obj.data.vertices)))
        vertex_group.add(index=verts, weight=1.0, type='REPLACE')

        bm = bmesh.new()
        bm.from_mesh(self.obj.data)
        bevel = bm.edges.layers.bevel_weight.verify()
        crease = bm.edges.layers.crease.verify()

        verts = []
        for v in bm.verts:
            if v.is_boundary:
                verts.append(v.index)
                continue

            for e in v.link_edges:
                if e.seam or not e.smooth or e[bevel] != 0.0 or e[crease] != 0.0:
                    verts.append(v.index)
                    continue

        vertex_group.remove(index=verts)

        self.mod.vertex_group = "HOPS_Smooth"


    def draw_ui(self, context):
        method_handler(self._draw_ui,
            arguments = (context, ),
            identifier = f'{self.bl_label} UI Shader',
            exit_method = self.remove_ui)


    def _draw_ui(self, context):
        x = self.mouse_start_x
        y = self.mouse_start_y

        set_drawing_dpi(get_dpi())
        f = get_dpi_factor()
        o = 5

        l1 = (3, 23, 4, 44)
        l2 = (46, 23, 4, 146)
        l3 = (149, 23, 4, 280)
        vertices = (
            (x + (l1[0] - o) * f, y + l1[1] * f), (x + l1[0] * f, y + l1[2] * f), (x + (l1[3] - o) * f, y + l1[1] * f), (x + l1[3] * f, y + l1[2] * f),
            (x + (l2[0] - o) * f, y + l2[1] * f), (x + l2[0] * f, y + l2[2] * f), (x + (l2[3] - o) * f, y + l2[1] * f), (x + l2[3] * f, y + l2[2] * f),
            (x + (l3[0] - o) * f, y + l3[1] * f), (x + l3[0] * f, y + l3[2] * f), (x + (l3[3] - o) * f, y + l3[1] * f), (x + l3[3] * f, y + l3[2] * f))

        l1 = (l1[0] - 15, l1[1], l1[2], l1[0] - 6)
        vertices2 = (
            (x + (l1[0] - o) * f, y + l1[1] * f), (x + l1[0] * f, y + l1[2] * f), (x + (l1[3] - o) * f, y + l1[1] * f), (x + l1[3] * f, y + l1[2] * f))

        indices = (
            (0, 1, 2), (1, 2, 3), (4, 5, 6), (5, 6, 7), (8, 9, 10), (9, 10, 11))

        indices2 = (
            (0, 1, 2), (1, 2, 3))

        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)

        c1 = get_preferences().color.Hops_hud_color
        c2 = get_preferences().color.Hops_hud_help_color
        c3 = get_preferences().color.Hops_hud_text_color

        shader.bind()
        shader.uniform_float("color", c1)
        glEnable(GL_BLEND)
        batch.draw(shader)
        glDisable(GL_BLEND)

        shader2 = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch2 = batch_for_shader(shader2, 'TRIS', {"pos": vertices2}, indices=indices2)
        shader2.bind()
        shader2.uniform_float("color", c2)

        glEnable(GL_BLEND)
        batch2.draw(shader2)
        glDisable(GL_BLEND)

        draw_text(f"{self.mod.iterations}", x + 10 * f, y + 9 * f, size=12, color=c3)
        draw_text(f"Factor: {self.mod.factor:.3f}", x + 60 * f, y + 9 * f, size=12, color=c3)
        mods = []
        if self.mod.use_x:
            mods.append('X')
        if self.mod.use_y:
            mods.append('Y')
        if self.mod.use_z:
            mods.append('Z')

        draw_text(f"Axis: {mods}", x + 154 * f, y + 9 * f, size=12, color=c3)

        self.draw_help(context, x, y, f)


    def draw_help(self, context, x, y, factor):
        # color_text1 = Hops_text_color()
        color_text2 = get_preferences().color.Hops_hud_help_color
        # color_border = Hops_border_color()
        # color_border2 = Hops_border2_color()

        if get_preferences().property.hops_modal_help:

            draw_text(" scroll - set iterations",
                      x + 45 * factor, y - 14 * factor, size=11, color=color_text2)

            draw_text(" X, Y, Z - set axis",
                      x + 45 * factor, y - 26 * factor, size=11, color=color_text2)

            draw_text("ctrl + X, Y, Z - add axis",
                      x + 45 * factor, y - 38 * factor, size=11, color=color_text2)

            draw_text(" H - Show/Hide Help",
                      x + 45 * factor, y - 50 * factor, size=11, color=color_text2)

        else:
            draw_text(" H - Show/Hide Help",
                      x + 45 * factor, y - 14 * factor, size=11, color=color_text2)


    def remove_ui(self):
        if self.draw_handler:
            self.draw_handler = bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
