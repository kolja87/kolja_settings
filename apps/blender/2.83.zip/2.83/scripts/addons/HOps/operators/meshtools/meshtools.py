import bpy
from bpy.props import IntProperty, BoolProperty, FloatProperty
from ... utils.addons import addon_exists
from ... utils.operations import invoke_individual_resizing
from ... preferences import get_preferences


class HOPS_OT_VertcircleOperator(bpy.types.Operator):
    bl_idname = "view3d.vertcircle"
    bl_label = "Vert To Circle"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = """LMB - convert vert to circle
LMB + CTRL - convert nth vert to circle
Shift - Bypass Scale

**Requires Looptools**

"""

    divisions: IntProperty(name="Division Count", description="Amount Of Vert divisions", default=5, min=3, max=10)
    c_offset: FloatProperty(name="Scale Offset", description="Amount of scale for circle bevel", default=0.2, min=0.002, max=2.2)

    message = "< Default >"

    nth_mode: BoolProperty(default=False)

    @classmethod
    def poll(cls, context):
        return getattr(context.active_object, "type", "") == "MESH"

    def draw(self, context):
        layout = self.layout
        if addon_exists("mesh_looptools"):
            layout.prop(self, "divisions")
            layout.prop(self, "c_offset")
        else:
            layout.label(text = "Looptools is not installed. Enable looptools in prefs")

    def invoke(self, context, event):
        if addon_exists("mesh_looptools"):
            if event.ctrl:
                self.nth_mode = True
                setup_verts(context.active_object, get_preferences().property.circle_divisions, self.nth_mode, self.c_offset)
                invoke_individual_resizing()
            if event.shift:
                setup_verts(context.active_object, get_preferences().property.circle_divisions, self.nth_mode, self.c_offset)
            else:
                setup_verts(context.active_object, get_preferences().property.circle_divisions, self.nth_mode, self.c_offset)
                invoke_individual_resizing()
        else:
            self.report({'INFO'}, "Looptools is not installed. Enable looptools in prefs")
        return {"FINISHED"}


def setup_verts(object, divisions, nth_mode, c_offset):
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')
    if nth_mode:
        bpy.ops.mesh.select_nth()
    bpy.ops.mesh.bevel(offset=c_offset, segments=divisions, vertex_only=True)
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.dissolve_mode()
    bpy.ops.mesh.looptools_circle()
