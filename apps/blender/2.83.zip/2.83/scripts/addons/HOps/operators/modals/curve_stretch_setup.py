import bpy
from mathutils import Vector
from bpy.types import Operator
from bpy.props import IntProperty, FloatProperty
from bgl import *
from gpu_extras.batch import batch_for_shader
from ... utils.blender_ui import get_dpi, get_dpi_factor
from ... graphics.drawing2d import draw_text, set_drawing_dpi, draw_box
from ... preferences import get_preferences


class HOPS_OT_CurveStretch(Operator):
    bl_idname = "mesh.curve_stretch"
    bl_label = "Curve Stretch Helper"
    bl_description = "Preconfiguration for Mira Tools Curve Stretch"
    bl_options = {"REGISTER", "GRAB_CURSOR", "BLOCKING"}

    first_mouse_x : IntProperty()
    first_value : FloatProperty()
    second_value : IntProperty()

    def modal(self, context, event):

        curve = context.scene.mi_cur_stretch_settings
        # offset_x = event.mouse_region_x - self.last_mouse_x

        if event.type == 'WHEELUPMOUSE':

            if curve.points_number < 12:

                curve.points_number += 1
                self.report({'INFO'}, F'Curve Points: {curve.points_number}')

        if event.type == 'WHEELDOWNMOUSE':

            if curve.points_number > 2:

                curve.points_number -= 1
                self.report({'INFO'}, F'Curve Points: {curve.points_number}')

        if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'}:

            bpy.ops.mira.curve_stretch('INVOKE_DEFAULT')
            self.finish()
            return {"FINISHED"}

        if event.type in {'RIGHTMOUSE', 'ESC', 'BACK_SPACE'}:
            return {'CANCELLED'}

        self.last_mouse_x = event.mouse_region_x
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.report({'INFO'}, F'HOPS: Frontend for Mira CurveStretch. Scroll to adjust count. Click to proceed')
        self.last_mouse_x = event.mouse_region_x
        self.start_mouse_position = Vector((event.mouse_region_x, event.mouse_region_y))

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def finish(self):
        return {"FINISHED"}

    def draw(self, context):
        x, y = self.start_mouse_position
        # first_value = self.first_value
        curve = context.scene.mi_cur_stretch_settings

        set_drawing_dpi(get_dpi())
        factor = get_dpi_factor()
        color_text1 = get_preferences().color.Hops_text_color
        color_text2 = get_preferences().color.Hops_hud_help_color
        color_border = get_preferences().color.Hops_border_color
        color_border2 = get_preferences().color.Hops_border2_color

        draw_box(x - 14 * factor, y + 8 * factor, 34 * factor, 34 * factor, color=color_border2)

        draw_text("{:.0f}".format(curve.points_number), x - 6 * factor, y, size=23, color=color_text1)
