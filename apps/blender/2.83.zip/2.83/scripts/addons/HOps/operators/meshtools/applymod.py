import bpy
# from ... utility import modifier
from ... addon.utility import modifier
from bpy.props import EnumProperty
from ... utils.objects import get_current_selected_status
from ... utils.context import ExecutionContext

from ... utils.modifiers import apply_modifiers
from ... preferences import get_preferences

class HOPS_OT_ApplyModifiers(bpy.types.Operator):
    bl_idname = "hops.apply_modifiers"
    bl_label = "Apply Modifiers"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {"REGISTER", "UNDO"}
    bl_description = """
LMB - Smart Apply Modifiers (does not apply last Bevel or Weighted Normal)
CTRL - Convert to curve and expand (edge / face)
SHIFT - Smart Apply (w/ Clear last Bevel and Weighted Normal)
ALT - Classic Step (bake bevel / readd bevel)

"""

    modifier_types: EnumProperty(
        name='Modifier Types',
        description='Settings to display',
        items=[
            ('NONE', 'All', ''),
            ('BOOLEAN', 'Boolean', ''),
            ('MIRROR', 'Mirror', ''),
            ('BEVEL', 'Bevel', ''),
            ('SOLIDIFY', 'Solidify', ''),
            ('ARRAY', 'Array', '')],
        default='BOOLEAN')


    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.label(text="Modifiers Applied")
        colrow = col.row(align=True)
        colrow.prop(self, "modifier_types", expand=True)

    def invoke(self, context, event):
        selected = context.selected_objects

        if event.ctrl:
            bpy.ops.object.convert(target='CURVE')
            self.report({'INFO'}, F'Converted to Curve')
            try:
                bpy.ops.hops.adjust_curve('INVOKE_DEFAULT')
            except:
                pass
        if event.alt:
            for obj in selected:
                bpy.ops.hops.step()
                self.report({'INFO'}, F'Object Stepped')
                return {"FINISHED"}

        for obj in selected:
            #if obj.hops.status == "UNDEFINED":
                #modifier.apply(obj=obj, modifiers=[mod for mod in obj.modifiers if mod.type in self.modifier_types])

            apply_mod(self, obj, clear_last=event.shift)
            self.report({'INFO'}, F'Modifiers Applied')

            #else:
            #    pass

        return {"FINISHED"}


def apply_mod(self, obj, clear_last=False):
    bevels = [mod for mod in obj.modifiers if mod.type == 'BEVEL']
    mirrors = [mod for mod in obj.modifiers if mod.type == 'MIRROR']
    excluded = [mod for mod in obj.modifiers if mod.type == 'WEIGHTED_NORMAL']

    if len(bevels) > 1 or (len(bevels) and bevels[0].limit_method in {'WEIGHT', 'ANGLE'}):
        excluded.append(bevels[-1])

    if len(mirrors) > 1:
        excluded.append(mirrors[-1])

    modifier.apply(obj, exclude=excluded)

    if clear_last:
        for mod in obj.modifiers:
            if mod.type in {'WEIGHTED_NORMAL', 'BEVEL'}:
                obj.modifiers.remove(mod)
