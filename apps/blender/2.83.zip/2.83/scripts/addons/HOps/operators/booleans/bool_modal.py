import bpy
import gpu

from mathutils import Vector

from . import operator

from . editmode_intersect import edit_bool_intersect
from . editmode_union import edit_bool_union
from . editmode_difference import edit_bool_difference
from . editmode_slash import edit_bool_slash
from . editmode_inset import edit_bool_inset
from . editmode_knife import edit_bool_knife

from bgl import *
from gpu_extras.batch import batch_for_shader
from ... utils.blender_ui import get_dpi, get_dpi_factor
from ... graphics.drawing2d import draw_text, set_drawing_dpi

from ... preferences import get_preferences


class HOPS_OT_BoolModal(bpy.types.Operator):
    bl_idname = "hops.bool_modal"
    bl_label = "Bool Modal"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}
    bl_description = """Modal operator for making booleans"""

    operation: bpy.props.EnumProperty(
        name="Operation",
        description="What kind of boolean operation to change to",
        items=[
            ('INTERSECT', "Intersect", "Peform an intersect operation"),
            ('UNION', "Union", "Peform a union operation"),
            ('DIFFERENCE', "Difference", "Peform a difference operation"),
            ('SLASH', "Slash", "Peform a slash operation"),
            ('INSET', "Inset", "Peform an inset operation"),
            ('OUTSET', "Outset", "Peform an outset operation"),
            ('KNIFE_BOOLEAN', "Knife Boolean", "Peform a knife boolean operation"),
            ('KNIFE_PROJECT', "Knife Project", "Peform a knife project operation")],
        default='DIFFERENCE')

    thickness: bpy.props.FloatProperty(
        name="Thickness",
        description="How deep the inset should cut",
        default=0.10,
        min=0.00,
        soft_max=10.0,
        step=1,
        precision=3)

    keep_bevels: bpy.props.BoolProperty(
        name="Keep Bevels",
        description="Keep Bevel modifiers on inset objects enabled if they don't use vertex groups or bevel weight",
        default=False)

    ignore_sort: bpy.props.BoolProperty(
        name="Ignore Sort",
        description="Ignore modifier sorting for this bool operation",
        default=False)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.mode in ('OBJECT', 'EDIT')

    def draw(self, context):
        self.layout.prop(self, "operation")

        if self.operation in ('INSET', 'OUTSET'):
            self.layout.prop(self, "thickness")

            if context.active_object.mode == 'OBJECT':
                row = self.layout.row()
                row.prop(self, "keep_bevels")
                row.prop(self, "ignore_sort")

        elif context.active_object.mode == 'OBJECT':
            self.layout.prop(self, "ignore_sort")

    def invoke(self, context, event):
        self.start_mouse_position = Vector((event.mouse_region_x, event.mouse_region_y))
        self.keep_bevels = event.ctrl
        self.ignore_sort = event.ctrl

        if event.shift:
            if self.operation == 'INSET':
                self.operation = 'OUTSET'

            if self.operation == 'KNIFE_BOOLEAN':
                self.operation = 'KNIFE_PROJECT'

        self.report_info(self.operation)
        self.get_overlays(context)
        self.execute(context)

        args = (context, )
        self.draw_handler = bpy.types.SpaceView3D.draw_handler_add(self.draw_ui, args, "WINDOW", "POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MIDDLEMOUSE':
            return {'PASS_THROUGH'}

        elif event.type == 'Z' and (event.shift or event.alt):
            return {'PASS_THROUGH'}

        elif event.type in ('LEFTMOUSE', 'SPACE'):
            self.report_info('FINISHED')
            self.reset_overlays(context)
            bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
            return {'FINISHED'}

        elif event.type in ('RIGHTMOUSE', 'ESC'):
            self.report_info('CANCELLED')
            self.reset_overlays(context)
            self.cancel(context)
            bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
            return {'CANCELLED'}

        elif event.type in ('WHEELDOWNMOUSE', 'WHEELUPMOUSE') or event.type == "X" and event.value == "PRESS":
            if event.type == 'WHEELDOWNMOUSE' or 'X':
                self.scroll_next()
            elif event.type == 'WHEELUPMOUSE':
                self.scroll_previous()

            self.report_info(self.operation)
            self.cancel(context)
            self.execute(context)

        if event.type == "H" and event.value == "PRESS":
            get_preferences().property.hops_modal_help = not get_preferences().property.hops_modal_help
            context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if context.active_object.mode == 'OBJECT':

            if self.operation in {'INTERSECT', 'UNION', 'DIFFERENCE', 'SLASH', 'INSET'}:
                operator.add(context, self.operation, sort=not self.ignore_sort, outset=False, thickness=self.thickness)
                self.reset_overlays(context)

            elif self.operation == 'OUTSET':
                operator.add(context, 'INSET', sort=not self.ignore_sort, outset=True, thickness=self.thickness)
                self.reset_overlays(context)

            elif self.operation == 'KNIFE_BOOLEAN':
                operator.knife(context, False)
                self.set_overlays(context)

            elif self.operation == 'KNIFE_PROJECT':
                operator.knife(context, True)
                self.set_overlays(context)

        elif context.active_object.mode == 'EDIT':
            if self.operation == 'INTERSECT':
                edit_bool_intersect(context, False)
                self.reset_overlays(context)

            elif self.operation == 'UNION':
                edit_bool_union(context, False)
                self.reset_overlays(context)

            elif self.operation == 'DIFFERENCE':
                edit_bool_difference(context, False)
                self.reset_overlays(context)

            elif self.operation == 'SLASH':
                edit_bool_slash(context, False)
                self.reset_overlays(context)

            elif self.operation == 'INSET':
                edit_bool_inset(context, False, False, self.thickness)
                self.reset_overlays(context)

            elif self.operation == 'OUTSET':
                edit_bool_inset(context, False, True, self.thickness)
                self.reset_overlays(context)

            elif self.operation == 'KNIFE_BOOLEAN':
                edit_bool_knife(context, False, False)
                self.reset_overlays(context)

            elif self.operation == 'KNIFE_PROJECT':
                edit_bool_knife(context, False, True)
                self.reset_overlays(context)

        return {'FINISHED'}

    def cancel(self, context):
        bpy.ops.ed.undo_push()
        bpy.ops.ed.undo()

    def report_info(self, info):
        words = [w.capitalize() for w in str(info).split("_")]
        self.report({'INFO'}, " ".join(words))

    def get_overlays(self, context):
        self.overlays = context.space_data.overlay.show_overlays
        self.wireframes = context.space_data.overlay.show_wireframes

    def set_overlays(self, context):
        context.space_data.overlay.show_overlays = True
        context.space_data.overlay.show_wireframes = True

    def reset_overlays(self, context):
        context.space_data.overlay.show_overlays = self.overlays
        context.space_data.overlay.show_wireframes = self.wireframes

    def scroll_next(self):
        if self.operation == 'INTERSECT':
            self.operation = 'UNION'
        elif self.operation == 'UNION':
            self.operation = 'DIFFERENCE'
        elif self.operation == 'DIFFERENCE':
            self.operation = 'SLASH'
        elif self.operation == 'SLASH':
            self.operation = 'INSET'
        elif self.operation == 'INSET':
            self.operation = 'OUTSET'
        elif self.operation == 'OUTSET':
            self.operation = 'KNIFE_BOOLEAN'
        elif self.operation == 'KNIFE_BOOLEAN':
            self.operation = 'KNIFE_PROJECT'
        elif self.operation == 'KNIFE_PROJECT':
            self.operation = 'INTERSECT'

    def scroll_previous(self):
        if self.operation == 'INTERSECT':
            self.operation = 'KNIFE_PROJECT'
        elif self.operation == 'KNIFE_PROJECT':
            self.operation = 'KNIFE_BOOLEAN'
        elif self.operation == 'KNIFE_BOOLEAN':
            self.operation = 'OUTSET'
        elif self.operation == 'OUTSET':
            self.operation = 'INSET'
        elif self.operation == 'INSET':
            self.operation = 'SLASH'
        elif self.operation == 'SLASH':
            self.operation = 'DIFFERENCE'
        elif self.operation == 'DIFFERENCE':
            self.operation = 'UNION'
        elif self.operation == 'UNION':
            self.operation = 'INTERSECT'


    def draw_ui(self, context):
        x, y = self.start_mouse_position
        mode = self.operation

        set_drawing_dpi(get_dpi())
        factor = get_dpi_factor()

        gap = 3 * factor

        offset = 5

        l1 = (-1, 23, 4, 210)

        vertices = (
            (x + (l1[0] - offset) * factor, y + l1[1] * factor), (x + l1[0] * factor, y + l1[2] * factor), (x + (l1[3] - offset) * factor, y + l1[1] * factor), (x + l1[3] * factor, y + l1[2] * factor),)

        l1 = (l1[0] - 15, l1[1], l1[2], l1[0] - 6)
        vertices2 = (
            (x + (l1[0] - offset) * factor, y + l1[1] * factor), (x + l1[0] * factor, y + l1[2] * factor), (x + (l1[3] - offset) * factor, y + l1[1] * factor), (x + l1[3] * factor, y + l1[2] * factor))

        indices = (
            (0, 1, 2), (1, 2, 3))

        indices2 = (
            (0, 1, 2), (1, 2, 3))

        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)

        shader.bind()
        shader.uniform_float("color", get_preferences().color.Hops_hud_color)
        glEnable(GL_BLEND)
        batch.draw(shader)
        glDisable(GL_BLEND)

        shader2 = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch2 = batch_for_shader(shader2, 'TRIS', {"pos": vertices2}, indices=indices2)
        shader2.bind()
        shader2.uniform_float("color", get_preferences().color.Hops_hud_help_color)

        glEnable(GL_BLEND)
        batch2.draw(shader2)
        glDisable(GL_BLEND)

        draw_text("Mode   -   {}".format(mode),
                  x + 27 * factor, y + 9 * factor, size=12, color=get_preferences().color.Hops_hud_text_color)


        self.draw_help(context, x, y, factor)

    def draw_help(self, context, x, y, factor):

        color_text1 = get_preferences().color.Hops_text_color
        color_text2 = get_preferences().color.Hops_hud_help_color
        color_border = get_preferences().color.Hops_border_color
        color_border2 = get_preferences().color.Hops_border2_color

        if get_preferences().property.hops_modal_help:
            draw_text(" wheel - cycle modifiers",
                      x + 45 * factor, y - 14 * factor, size=11, color=color_text2)

            draw_text(" H - Show/Hide Help",
                      x + 45 * factor, y - 26 * factor, size=11, color=color_text2)

        else:
            draw_text(" H - Show/Hide Help",
                      x + 45 * factor, y - 14 * factor, size=11, color=color_text2)
