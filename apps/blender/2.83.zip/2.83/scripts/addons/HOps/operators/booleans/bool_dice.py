import bpy, bmesh, gpu, bgl, mathutils, math, copy
from gpu_extras.batch import batch_for_shader
from ... graphics.drawing2d import draw_text, set_drawing_dpi
from ... utils.blender_ui import get_dpi, get_dpi_factor
from ... preferences import get_preferences
from ... utility.renderer import cycles
from ... utils.objects import set_active
from ... utility import collections
from . import operator


class HOPS_OT_BoolDice(bpy.types.Operator):
    bl_idname = "hops.bool_dice"
    bl_label = "Hops Boolean Dice"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING', 'GRAB_CURSOR'}
    bl_description = """LMB - Dice on last used axes
Shift + LMB - Use alternate cutting method
Ctrl + LMB - Dice on all axes"""

    axis: bpy.props.EnumProperty(
        name="Axis",
        description="What axis to dice on",
        items=[
            ('X', "X", "Dice on the X axis"),
            ('Y', "Y", "Dice on the Y axis"),
            ('Z', "Z", "Dice on the Z axis")],
        default='X')

    axes: bpy.props.BoolVectorProperty(
        name="Axes",
        description="Which axes to dice on",
        default=(True, False, False),
        size=3)

    count: bpy.props.IntProperty(
        name="Count",
        description="How many cutting planes to make on each axis",
        min=1,
        soft_max=100,
        default=5)

    use_knife_project: bpy.props.BoolProperty(
        name="Use Knife Project",
        description="Otherwise use mesh intersect",
        default=True)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode in {'OBJECT', 'EDIT'}

    def draw(self, context):
        axes = ", ".join(a for i,a in enumerate("XYZ") if self.axes[i])
        self.layout.label(text=f"Axes: {axes}")
        self.layout.label(text=f"Segments: {self.count}")
        self.layout.label(text=f"Method: {'Knife Project' if self.use_knife_project else 'Mesh Intersect'}")

    # Without execute, draw doesn't work
    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        self.modal_scale = get_preferences().ui.Hops_modal_scale
        self.obj = context.active_object
        self.mode = self.obj.mode

        self.selected = context.selected_objects[:]
        set_active(self.obj, select=True, only_select=True)

        self.bound_box = self.get_bound_box(context, self.obj)
        self.size = self.get_size(context, self.bound_box)

        self.adjusting = get_preferences().property.dice_adjust
        if event.ctrl and event.type == 'LEFTMOUSE':
            self.adjusting = 'NONE'

        self.axis_buffer = float("XYZ".find(self.axis))
        self.count_buffer = self.count

        self.plane_x = self.create_plane(context, 'X')
        self.plane_y = self.create_plane(context, 'Y')
        self.plane_z = self.create_plane(context, 'Z')

        if event.type == 'LEFTMOUSE' and event.ctrl:
            self.axes[0] = True
            self.axes[1] = True
            self.axes[2] = True

        self.plane_x.hide_set(not self.axes[0])
        self.plane_y.hide_set(not self.axes[1])
        self.plane_z.hide_set(not self.axes[2])

        self.use_knife_project = get_preferences().property.dice_method == 'KNIFE_PROJECT'
        if event.shift and event.type == 'LEFTMOUSE':
            self.use_knife_project = not self.use_knife_project

        self.mouse_prev_x = event.mouse_region_x
        self.mouse_start_x = event.mouse_region_x
        self.mouse_start_y = event.mouse_region_y

        self.add_draw_handler(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MIDDLEMOUSE':
            return {'PASS_THROUGH'}

        elif event.type == 'Z' and (event.shift or event.alt):
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE'}:
            self.remove_draw_handler(context)

            if not event.shift:
                set_active(self.obj, select=True, only_select=True)

                if self.axes[0]:
                    self.knife(context, 'X')
                if self.axes[1]:
                    self.knife(context, 'Y')
                if self.axes[2]:
                    self.knife(context, 'Z')

                self.remove_plane(context, self.plane_x)
                self.remove_plane(context, self.plane_y)
                self.remove_plane(context, self.plane_z)

            else:
                if not self.axes[0]:
                    self.remove_plane(context, self.plane_x)
                else:
                    collections.unlink_obj(context, self.plane_x)
                    collections.link_obj(context, self.plane_x, "Cutters")

                if not self.axes[1]:
                    self.remove_plane(context, self.plane_y)
                else:
                    collections.unlink_obj(context, self.plane_y)
                    collections.link_obj(context, self.plane_y, "Cutters")

                if not self.axes[2]:
                    self.remove_plane(context, self.plane_z)
                else:
                    collections.unlink_obj(context, self.plane_z)
                    collections.link_obj(context, self.plane_z, "Cutters")

            set_active(self.obj)
            for obj in self.selected:
                obj.select_set(True)

            self.report({'INFO'}, "Finished")
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.remove_draw_handler(context)

            self.remove_plane(context, self.plane_x)
            self.remove_plane(context, self.plane_y)
            self.remove_plane(context, self.plane_z)

            set_active(self.obj)
            for obj in self.selected:
                obj.select_set(True)

            self.report({'INFO'}, "Cancelled")
            return {'CANCELLED'}

        elif event.type == 'A' and event.value == 'PRESS':
            self.adjusting = 'NONE' if self.adjusting == 'AXIS' else 'AXIS'
            self.report({'INFO'}, f"{'Started' if self.adjusting != 'NONE' else 'Stopped'} Adjusting Axis")

        elif event.type == 'S' and event.value == 'PRESS':
            self.adjusting = 'NONE' if self.adjusting == 'SEGMENTS' else 'SEGMENTS'
            self.report({'INFO'}, f"{'Started' if self.adjusting != 'NONE' else 'Stopped'} Adjusting Segments")

        elif event.type == 'MOUSEMOVE' and self.adjusting == 'AXIS':
            divisor = self.modal_scale * (2500 if event.shift else 250)
            offset = event.mouse_region_x - self.mouse_prev_x

            self.axis_buffer -= offset / divisor / get_dpi_factor()
            self.axis = "XYZ"[round(self.axis_buffer) % 3]

            self.axes[0] = self.axis == 'X'
            self.axes[1] = self.axis == 'Y'
            self.axes[2] = self.axis == 'Z'

            self.plane_x.hide_set(not self.axes[0])
            self.plane_y.hide_set(not self.axes[1])
            self.plane_z.hide_set(not self.axes[2])

            context.area.tag_redraw()

        elif event.type == 'MOUSEMOVE' and self.adjusting == 'SEGMENTS':
            divisor = self.modal_scale * (1000 if event.shift else 100)
            offset = event.mouse_region_x - self.mouse_prev_x

            self.count_buffer -= offset / divisor / get_dpi_factor()
            self.count_buffer = max(self.count_buffer, 1)
            self.count = round(self.count_buffer)

            for index, plane in enumerate([self.plane_x, self.plane_y, self.plane_z]):
                distance = self.size[index] / (self.count + 1)
                plane.modifiers["Array"].count = self.count
                plane.modifiers["Array"].constant_offset_displace[index] = distance
                plane.modifiers["Displace"].strength = distance

            context.area.tag_redraw()

        elif event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.type in {'NUMPAD_PLUS', 'NUMPAD_MINUS'} and event.value == 'PRESS':
            offset = 1 if event.type in {'WHEELUPMOUSE', 'NUMPAD_PLUS'} else -1
            self.count_buffer += offset
            self.count_buffer = max(self.count_buffer, 1)
            self.count = round(self.count_buffer)

            for index, plane in enumerate([self.plane_x, self.plane_y, self.plane_z]):
                distance = self.size[index] / (self.count + 1)
                plane.modifiers["Array"].count = self.count
                plane.modifiers["Array"].constant_offset_displace[index] = distance
                plane.modifiers["Displace"].strength = distance

            context.area.tag_redraw()

        elif event.type == 'X' and event.value == 'PRESS' and (self.axes[1] or self.axes[2]):
            self.adjusting = 'NONE'
            self.axes[0] = not self.axes[0]

            if self.axes[0]:
                self.axis = 'X'
                self.axis_buffer = 0

            self.plane_x.hide_set(not self.axes[0])
            self.report({'INFO'}, f"{'Enabled' if self.axes[0] else 'Disabled'} Axis X")

        elif event.type == 'Y' and event.value == 'PRESS' and (self.axes[0] or self.axes[2]):
            self.adjusting = 'NONE'
            self.axes[1] = not self.axes[1]

            if self.axes[1]:
                self.axis = 'Y'
                self.axis_buffer = 1

            self.plane_y.hide_set(not self.axes[1])
            self.report({'INFO'}, f"{'Enabled' if self.axes[1] else 'Disabled'} Axis Y")

        elif event.type == 'Z' and event.value == 'PRESS' and (self.axes[0] or self.axes[1]):
            self.adjusting = 'NONE'
            self.axes[2] = not self.axes[2]

            if self.axes[2]:
                self.axis = 'Z'
                self.axis_buffer = 2

            self.plane_z.hide_set(not self.axes[2])
            self.report({'INFO'}, f"{'Enabled' if self.axes[2] else 'Disabled'} Axis Z")

        elif event.type == 'Q' and event.value == 'PRESS':
            self.use_knife_project = not self.use_knife_project
            self.report({'INFO'}, f"Method: {'Knife Project' if self.use_knife_project else 'Mesh Intersect'}")

        elif event.type in {'ONE', 'TWO', 'THREE', 'FOUR'} and event.value == 'PRESS':
            if event.type == 'ONE':
                self.count = self.count_buffer = 7
            elif event.type == 'TWO':
                self.count = self.count_buffer = 15
            elif event.type == 'THREE':
                self.count = self.count_buffer = 23
            elif event.type == 'FOUR':
                self.count = self.count_buffer = 31

            for index, plane in enumerate([self.plane_x, self.plane_y, self.plane_z]):
                distance = self.size[index] / (self.count + 1)
                plane.modifiers["Array"].count = self.count
                plane.modifiers["Array"].constant_offset_displace[index] = distance
                plane.modifiers["Displace"].strength = distance

            context.area.tag_redraw()

        elif event.type == 'H' and event.value == 'PRESS':
            get_preferences().property.hops_modal_help = not get_preferences().property.hops_modal_help
            context.area.tag_redraw()
            self.report({'INFO'}, f"{'Show' if get_preferences().property.hops_modal_help else 'Hide'} Help")

        self.mouse_prev_x = event.mouse_region_x
        return {'RUNNING_MODAL'}

    def get_bound_box(self, context, obj):
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode=self.mode)
        temp = bpy.data.objects.new("Bounding Box", obj.data)
        bound_box = [(x,y,z) for (x,y,z) in temp.bound_box]
        bpy.data.objects.remove(temp)
        return bound_box

    def get_size(self, context, bb):
        size_x = bb[6][0] - bb[0][0]
        size_y = bb[6][1] - bb[0][1]
        size_z = bb[6][2] - bb[0][2]
        return (size_x, size_y, size_z)

    def create_plane(self, context, axis):
        bb = [list(v) for v in self.bound_box]

        if axis != 'X':
            bb[0][0] -= 0.01
            bb[1][0] -= 0.01
            bb[2][0] -= 0.01
            bb[3][0] -= 0.01
            bb[4][0] += 0.01
            bb[5][0] += 0.01
            bb[6][0] += 0.01
            bb[7][0] += 0.01

        if axis != 'Y':
            bb[0][1] -= 0.01
            bb[1][1] -= 0.01
            bb[2][1] += 0.01
            bb[3][1] += 0.01
            bb[4][1] -= 0.01
            bb[5][1] -= 0.01
            bb[6][1] += 0.01
            bb[7][1] += 0.01

        if axis != 'Z':
            bb[0][2] -= 0.01
            bb[1][2] += 0.01
            bb[2][2] += 0.01
            bb[3][2] -= 0.01
            bb[4][2] -= 0.01
            bb[5][2] += 0.01
            bb[6][2] += 0.01
            bb[7][2] -= 0.01

        if axis == 'X':
            bb = [bb[0], bb[1], bb[2], bb[3]]
        if axis == 'Y':
            bb = [bb[0], bb[4], bb[5], bb[1]]
        if axis == 'Z':
            bb = [bb[0], bb[3], bb[7], bb[4]]

        plane_bm = bmesh.new()
        for vert in bb:
            plane_bm.verts.new(vert)
        plane_bm.faces.new(plane_bm.verts)

        plane_mesh = bpy.data.meshes.new(f"Cutter {axis}")
        plane_bm.to_mesh(plane_mesh)
        plane_bm.free()

        plane_obj = self.obj.copy()
        for col in self.obj.users_collection:
            col.objects.link(plane_obj)

        plane_obj.name = f"Cutter {axis}"
        plane_obj.data = plane_mesh
        plane_obj.modifiers.clear()
        plane_obj.select_set(False)

        cycles.hide_preview(context, plane_obj)
        plane_obj.hops.status = 'BOOLSHAPE'
        plane_obj.display_type = 'WIRE'
        plane_obj.hide_render = True

        array = plane_obj.modifiers.new("Array", 'ARRAY')
        array.use_relative_offset = False
        array.use_constant_offset = True
        array.fit_type = 'FIXED_COUNT'
        array.count = self.count

        displace = plane_obj.modifiers.new("Displace", 'DISPLACE')
        displace.direction = axis
        displace.mid_level = 0.0

        axis = "XYZ".find(axis)
        distance = self.size[axis] / (self.count + 1)
        array.constant_offset_displace[axis] = distance
        displace.strength = distance

        return plane_obj

    def remove_plane(self, context, obj):
        mesh = obj.data
        bpy.data.objects.remove(obj)
        bpy.data.meshes.remove(mesh)

    def knife(self, context, axis):
        bpy.ops.object.mode_set(mode='OBJECT')

        self.plane_x.select_set(axis == 'X')
        self.plane_y.select_set(axis == 'Y')
        self.plane_z.select_set(axis == 'Z')

        if self.use_knife_project:
            self.knife_project(context, axis)
        else:
            self.knife_intersect(context, axis)

        bpy.ops.object.mode_set(mode=self.mode)

    def knife_project(self, context, axis):
        perspective = copy.copy(context.region_data.view_perspective)
        camera_zoom = copy.copy(context.region_data.view_camera_zoom)
        distance = copy.copy(context.region_data.view_distance)
        location = copy.copy(context.region_data.view_location)
        rotation = copy.copy(context.region_data.view_rotation)

        view = {'X': 'FRONT', 'Y': 'TOP', 'Z': 'RIGHT'}[axis]
        bpy.ops.view3d.view_axis(type=view, align_active=True)
        context.region_data.view_perspective = 'ORTHO'
        context.region_data.update()

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.knife_project(cut_through=True)
        bpy.ops.object.mode_set(mode='OBJECT')

        context.region_data.view_perspective = perspective
        context.region_data.view_camera_zoom = camera_zoom
        context.region_data.view_distance = distance
        context.region_data.view_location = location
        context.region_data.view_rotation = rotation
        context.region_data.update()

        if perspective == 'ORTHO':
            axis = [int(math.degrees(a)) for a in mathutils.Quaternion(rotation).to_euler()]

            if axis == [90, 0, 90]:
                bpy.ops.view3d.view_axis(type='RIGHT')
            elif axis == [90, 0, 0]:
                bpy.ops.view3d.view_axis(type='FRONT')
            elif axis == [0, 0, 0]:
                bpy.ops.view3d.view_axis(type='TOP')
            elif axis == [90, 0, -90]:
                bpy.ops.view3d.view_axis(type='LEFT')
            elif axis == [90, 0, 180]:
                bpy.ops.view3d.view_axis(type='BACK')
            elif axis == [180, 0, 0]:
                bpy.ops.view3d.view_axis(type='BOTTOM')

    def knife_intersect(self, context, axis):
        bpy.ops.object.mode_set(mode='OBJECT')
        operator.knife(context, knife_project=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')

    def add_draw_handler(self, context):
        self.draw_handler = bpy.types.SpaceView3D.draw_handler_add(self.draw_ui, (context, ), "WINDOW", "POST_PIXEL")
        context.area.header_text_set(text=None)
        context.area.tag_redraw()

    def remove_draw_handler(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
        context.area.header_text_set(text=None)
        context.area.tag_redraw()

    def draw_ui(self, context):
        x = self.mouse_start_x
        y = self.mouse_start_y

        c1 = get_preferences().color.Hops_hud_color
        c2 = get_preferences().color.Hops_hud_help_color
        c3 = get_preferences().color.Hops_hud_text_color

        set_drawing_dpi(get_dpi())
        f = get_dpi_factor()
        o = 5

        l1 = (3, 23, 4, 63)
        l2 = (65, 23, 4, 105)

        vertices1 = (
            (x + (l1[0] - o) * f, y + l1[1] * f),
            (x + l1[0] * f, y + l1[2] * f),
            (x + (l1[3] - o) * f, y + l1[1] * f),
            (x + l1[3] * f, y + l1[2] * f),

            (x + (l2[0] - o) * f, y + l2[1] * f),
            (x + l2[0] * f, y + l2[2] * f),
            (x + (l2[3] - o) * f, y + l2[1] * f),
            (x + l2[3] * f, y + l2[2] * f))

        l1 = (l1[0] - 15, l1[1], l1[2], l1[0] - 6)

        vertices2 = (
            (x + (l1[0] - o) * f, y + l1[1] * f),
            (x + l1[0] * f, y + l1[2] * f),
            (x + (l1[3] - o) * f, y + l1[1] * f),
            (x + l1[3] * f, y + l1[2] * f))

        indices1 = (
            (0, 1, 2),
            (1, 2, 3),

            (4, 5, 6),
            (5, 6, 7))

        indices2 = (
            (0, 1, 2),
            (1, 2, 3))

        shader1 = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch1 = batch_for_shader(shader1, 'TRIS', {"pos": vertices1}, indices=indices1)
        shader1.bind()
        shader1.uniform_float("color", c1)

        bgl.glEnable(bgl.GL_BLEND)
        batch1.draw(shader1)
        bgl.glDisable(bgl.GL_BLEND)

        shader2 = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch2 = batch_for_shader(shader2, 'TRIS', {"pos": vertices2}, indices=indices2)
        shader2.bind()
        shader2.uniform_float("color", c2)

        bgl.glEnable(bgl.GL_BLEND)
        batch2.draw(shader2)
        bgl.glDisable(bgl.GL_BLEND)

        axes = ", ".join(a for i,a in enumerate("XYZ") if self.axes[i])
        draw_text(f"{axes}", x + 13 * f, y + 9 * f, size=12, color=c3)

        draw_text(f"{self.count}", x + 70 * f, y + 9 * f, size=12, color=c3)
        self.draw_help(context, x, y, f)

    def draw_help(self, context, x, y, f):
        c2 = get_preferences().color.Hops_hud_help_color

        if get_preferences().property.hops_modal_help:
            draw_text(" Shift + LMB / Space - Create cutters but don't perform cut", x + 45 * f, y - 14 * f, size=11, color=c2)
            draw_text(" X / Y / Z - Toggle dicing per axis", x + 45 * f, y - 26 * f, size=11, color=c2)
            draw_text(" 1 / 2 / 3 / 4 - Set segments to 7 / 15 / 23 / 31", x + 45 * f, y - 38 * f, size=11, color=c2)
            draw_text(" S - Adjust Segments", x + 45 * f, y - 50 * f, size=11, color=c2)
            draw_text(" Q - Toggle Knife Project / Mesh Intersect", x + 45 * f, y - 62 * f, size=11, color=c2)
            draw_text(" H - Show/Hide Help", x + 45 * f, y - 74 * f, size=11, color=c2)

        else:
            draw_text(" H - Show/Hide Help", x + 45 * f, y - 14 * f, size=11, color=c2)
