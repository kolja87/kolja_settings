import bpy, bmesh, gpu, bgl
from gpu_extras.batch import batch_for_shader
from ... graphics.drawing2d import draw_text, set_drawing_dpi, draw_box
from ... utils.blender_ui import get_dpi, get_dpi_factor
from ... preferences import get_preferences


class HOPS_OT_MaterialScroll(bpy.types.Operator):
    bl_idname = "hops.material_scroll"
    bl_label = "Material Scroll"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING', 'GRAB_CURSOR'}
    bl_description = """Scroll through materials

Press H for help
"""

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode in {'OBJECT', 'EDIT'}

    def invoke(self, context, event):
        bpy.context.space_data.overlay.show_overlays = False
        self.modal_scale = get_preferences().ui.Hops_modal_scale

        self.active = context.active_object
        self.objects = [obj for obj in context.selected_objects if obj.type == 'MESH']

        if self.active.mode == 'OBJECT':
            self.materials = {o:[s.material for s in o.material_slots] for o in self.objects}
            self.indices = {o:[p.material_index for p in o.data.polygons] for o in self.objects}

            for object in self.objects:
                object.data.materials.clear()
                object.data.materials.append(None)

        elif self.active.mode == 'EDIT':
            self.indices = [p.material_index for p in self.active.data.polygons]
            bpy.ops.object.material_slot_add()
            bpy.ops.object.material_slot_assign()

        self.index = 0
        material = bpy.data.materials[0]
        self.assign(material)

        self.mouse_prev_x = event.mouse_region_x
        self.mouse_start_x = event.mouse_region_x
        self.mouse_start_y = event.mouse_region_y

        self.add_draw_handler(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MIDDLEMOUSE':
            return {'PASS_THROUGH'}

        elif event.type == 'Z' and (event.shift or event.alt):
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE'}:
            self.remove_draw_handler(context)
            bpy.context.space_data.overlay.show_overlays = True
            self.report({'INFO'}, "Finished")
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.remove_draw_handler(context)
            self.cancel(context)
            self.report({'INFO'}, "Cancelled")
            return {'CANCELLED'}

        elif event.type in {'WHEELDOWNMOUSE', 'WHEELUPMOUSE'}:
            direction = 1 if event.type == 'WHEELDOWNMOUSE' else -1
            self.index = (self.index + direction) % len(bpy.data.materials)
            material = bpy.data.materials[self.index]
            self.assign(material)
            self.report({'INFO'}, f"Scrolled to {material.name}")

        elif event.type in {'Z', 'X'} and event.value == 'PRESS':
            direction = 1 if event.type == 'X' else -1
            self.index = (self.index + direction) % len(bpy.data.materials)
            material = bpy.data.materials[self.index]
            self.assign(material)
            self.report({'INFO'}, f"Scrolled to {material.name}")

        elif event.type == 'H' and event.value == 'PRESS':
            get_preferences().property.hops_modal_help = not get_preferences().property.hops_modal_help
            context.area.tag_redraw()
            self.report({'INFO'}, f"{'Show' if get_preferences().property.hops_modal_help else 'Hide'} Help")

        self.mouse_prev_x = event.mouse_region_x
        return {'RUNNING_MODAL'}

    def assign(self, material):
        if self.active.mode == 'OBJECT':
            for object in self.objects:
                object.material_slots[-1].material = material

        elif self.active.mode == 'EDIT':
            self.active.material_slots[-1].material = material

    def cancel(self, context):
        if self.active.mode == 'OBJECT':
            for object in self.objects:
                object.data.materials.clear()

                for material in self.materials[object]:
                    object.data.materials.append(material)

                for index, poly in enumerate(object.data.polygons):
                    poly.material_index = self.indices[object][index]

        elif self.active.mode == 'EDIT':
            bpy.ops.object.editmode_toggle()

            bpy.ops.object.material_slot_remove()

            for index, poly in enumerate(self.active.data.polygons):
                poly.material_index = self.indices[index]

            bpy.ops.object.editmode_toggle()

    def add_draw_handler(self, context):
        self.draw_handler = bpy.types.SpaceView3D.draw_handler_add(self.draw_ui, (context, ), "WINDOW", "POST_PIXEL")
        context.area.header_text_set(text=None)
        context.area.tag_redraw()

    def remove_draw_handler(self, context):
        self.draw_handler = bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
        context.area.header_text_set(text=None)
        context.area.tag_redraw()

    def draw_ui(self, context):
        x = self.mouse_start_x
        y = self.mouse_start_y

        c1 = get_preferences().color.Hops_hud_color
        c2 = get_preferences().color.Hops_hud_help_color
        c3 = get_preferences().color.Hops_hud_text_color

        set_drawing_dpi(get_dpi())
        f = get_dpi_factor()
        o = 5

        l1 = (3, 23, 4, 34)
        l2 = (36, 23, 4, 246)

        vertices = (
            (x + (l1[0] - o) * f, y + l1[1] * f),
            (x + l1[0] * f, y + l1[2] * f),
            (x + (l1[3] - o) * f, y + l1[1] * f),
            (x + l1[3] * f, y + l1[2] * f),

            (x + (l2[0] - o) * f, y + l2[1] * f),
            (x + l2[0] * f, y + l2[2] * f),
            (x + (l2[3] - o) * f, y + l2[1] * f),
            (x + l2[3] * f, y + l2[2] * f))

        l1 = (l1[0] - 15, l1[1], l1[2], l1[0] - 6)

        vertices2 = (
            (x + (l1[0] - o) * f, y + l1[1] * f),
            (x + l1[0] * f, y + l1[2] * f),
            (x + (l1[3] - o) * f, y + l1[1] * f),
            (x + l1[3] * f, y + l1[2] * f))

        indices = (
            (0, 1, 2),
            (1, 2, 3),
            (4, 5, 6),
            (5, 6, 7))

        indices2 = (
            (0, 1, 2),
            (1, 2, 3))

        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)
        shader.bind()
        shader.uniform_float("color", c1)

        bgl.glEnable(bgl.GL_BLEND)
        batch.draw(shader)
        bgl.glDisable(bgl.GL_BLEND)

        shader2 = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch2 = batch_for_shader(shader2, 'TRIS', {"pos": vertices2}, indices=indices2)
        shader2.bind()
        shader2.uniform_float("color", c2)

        bgl.glEnable(bgl.GL_BLEND)
        batch2.draw(shader2)
        bgl.glDisable(bgl.GL_BLEND)

        draw_text(f"{self.index}", x + 10 * f, y + 9 * f, size=12, color=c3)
        draw_text(f"{bpy.data.materials[self.index].name}", x + 42 * f, y + 9 * f, size=12, color=c3)

        if get_preferences().property.hops_modal_help:
            draw_text(" Scroll - Increment Material", x + 45 * f, y - 14 * f, size=11, color=c2)
            draw_text(" Z / X - Increment Material", x + 45 * f, y - 26 * f, size=11, color=c2)
            draw_text(" H - Show/Hide Help", x + 45 * f, y - 38 * f, size=11, color=c2)

        else:
            draw_text(" H - Show/Hide Help", x + 45 * f, y - 14 * f, size=11, color=c2)
