import bpy, bmesh, gpu, bgl, math, mathutils
from gpu_extras.batch import batch_for_shader
from ... graphics.drawing2d import draw_text, set_drawing_dpi, draw_box
from ... utils.blender_ui import get_dpi, get_dpi_factor
from ... preferences import get_preferences
from ... utility import modifier


class HOPS_OT_MOD_Twist360(bpy.types.Operator):
    bl_idname = "array.twist"
    bl_label = "Array Twist"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING', 'GRAB_CURSOR'}
    bl_description = """Adds an array modifier and deforms the mesh 360 degrees
LMB + Shift - Don't merge segments

Press H for help"""

    axis: bpy.props.EnumProperty(
        name="Axis",
        description="What axis to twist around on",
        items=[
            ('X', "X", "Twist around the X axis"),
            ('Y', "Y", "Twist around the Y axis"),
            ('Z', "Z", "Twist around the Z axis")],
        default='Z')

    count: bpy.props.IntProperty(
        name="Count",
        description="How many segments to make",
        min=1,
        soft_max=100,
        default=8)

    displace: bpy.props.FloatProperty(
        name="Displace",
        description="How far in or out to displace",
        default=-1)

    angle: bpy.props.FloatProperty(
        name="Angle",
        description="How many degrees to twist",
        default=360)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode == 'OBJECT'

    def draw(self, context):
        self.layout.label(text=f"Axis: {self.axis}")
        self.layout.label(text=f"Segments: {self.count}")
        self.layout.label(text=f"Displace: {self.displace:.3f}")
        self.layout.label(text=f"Angle: {self.angle:.0f}")
        self.layout.label(text=f"Merge Segments: {'Yes' if self.merge_segments else 'No'}")

    # Without execute, draw doesn't work
    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        self.modal_scale = get_preferences().ui.Hops_modal_scale
        self.obj = context.active_object

        self.merge_segments = not event.shift
        self.adjusting = 'NONE'

        self.displace_mod_one = None
        self.array_mod = None
        self.deform_mod = None
        self.displace_mod_two = None
        self.weld_mod = None

        for a, b, c, d, e in zip(self.obj.modifiers[:-3], self.obj.modifiers[1:-2], self.obj.modifiers[2:-1], self.obj.modifiers[3:], self.obj.modifiers[4:] + [None]):
            if a.type == 'DISPLACE' and b.type == 'ARRAY' and c.type == 'SIMPLE_DEFORM' and d.type == 'DISPLACE':
                self.displace_mod_one = a
                self.array_mod = b
                self.deform_mod = c
                self.displace_mod_two = d

                if e and e.type == 'WELD':
                    self.weld_mod = e

                break

        self.displace_new_one = False
        self.array_new = False
        self.deform_new = False
        self.displace_new_two = False
        self.weld_new = False

        if not self.displace_mod_one:
            self.displace_mod_one = self.obj.modifiers.new("Displace One", 'DISPLACE')
            self.displace_mod_one.show_expanded = False
            self.displace_mod_one.show_render = False
            self.displace_mod_one.show_in_editmode = True
            self.displace_mod_one.mid_level = 0.0
            self.displace_mod_one.direction = 'X' if self.axis == 'Y' else 'Y'
            self.displace_mod_one.strength = self.displace
            self.displace_new_one = True

        if not self.array_mod:
            self.array_mod = self.obj.modifiers.new("Array", 'ARRAY')
            self.array_mod.show_expanded = False
            self.array_mod.show_render = False
            self.array_mod.show_in_editmode = True
            self.array_mod.count = self.count
            self.array_new = True

        if not self.deform_mod:
            self.deform_mod = self.obj.modifiers.new("Simple Deform", 'SIMPLE_DEFORM')
            self.deform_mod.show_expanded = False
            self.deform_mod.show_render = False
            self.deform_mod.show_in_editmode = True
            self.deform_mod.angle = math.radians(self.angle)
            self.deform_mod.deform_method = 'BEND'
            self.deform_mod.deform_axis = self.axis
            self.deform_new = True

        if not self.displace_mod_two:
            self.displace_mod_two = self.obj.modifiers.new("Displace Two", 'DISPLACE')
            self.displace_mod_two.show_expanded = False
            self.displace_mod_two.show_render = False
            self.displace_mod_two.show_in_editmode = True
            self.displace_mod_two.mid_level = 0.0
            self.displace_mod_two.direction = 'X' if self.axis == 'Y' else 'Y'
            self.displace_mod_two.strength = -1.0
            self.displace_new_two = True

        if not self.weld_mod and self.merge_segments:
            try:
                self.weld_mod = self.obj.modifiers.new("Weld", 'WELD')
                self.weld_mod.show_expanded = False
                self.weld_mod.show_render = False
                self.weld_mod.show_in_editmode = True
                self.weld_new = True

            except:
                self.report({'INFO'}, "Unable to add Weld modifier")

        self.displace_settings_one = {}
        self.displace_settings_one["direction"] = self.displace_mod_one.direction
        self.displace_settings_one["strength"] = self.displace_mod_one.strength

        self.array_settings = {}
        self.array_settings["use_constant_offset"] = self.array_mod.use_constant_offset
        self.array_settings["use_relative_offset"] = self.array_mod.use_relative_offset
        self.array_settings["use_object_offset"] = self.array_mod.use_object_offset
        self.array_settings["displace_x"] = self.array_mod.relative_offset_displace[0]
        self.array_settings["displace_y"] = self.array_mod.relative_offset_displace[1]
        self.array_settings["displace_z"] = self.array_mod.relative_offset_displace[2]
        self.array_settings["use_merge_vertices"] = self.array_mod.use_merge_vertices
        self.array_settings["fit_type"] = self.array_mod.fit_type
        self.array_settings["count"] = self.array_mod.count

        self.deform_settings = {}
        self.deform_settings["deform_method"] = self.deform_mod.deform_method
        self.deform_settings["deform_axis"] = self.deform_mod.deform_axis
        self.deform_settings["angle"] = self.deform_mod.angle

        self.displace_settings_two = {}
        self.displace_settings_two["direction"] = self.displace_mod_two.direction
        self.displace_settings_two["strength"] = self.displace_mod_two.strength

        self.array_mod.use_constant_offset = False
        self.array_mod.use_relative_offset = True
        self.array_mod.use_object_offset = False
        self.array_mod.relative_offset_displace = (1.0, 0.0, 0.0) if self.deform_mod.deform_axis == 'Z' else (0.0, 0.0, 1.0)
        self.array_mod.use_merge_vertices = self.merge_segments

        if self.weld_mod:
            self.weld_settings = {}
            self.weld_settings["show_viewport"] = self.weld_mod.show_viewport
            self.weld_mod.show_viewport = self.merge_segments

        self.axis = self.deform_mod.deform_axis
        self.count = self.count_buffer = self.array_mod.count
        self.displace = self.displace_buffer = self.displace_mod_one.strength
        self.angle = self.angle_buffer = math.degrees(self.deform_mod.angle)

        self.mouse_prev_x = event.mouse_region_x
        self.mouse_start_x = event.mouse_region_x
        self.mouse_start_y = event.mouse_region_y

        self.center(context)

        self.add_draw_handler(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MIDDLEMOUSE':
            return {'PASS_THROUGH'}

        elif event.type == 'Z' and (event.shift or event.alt):
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE'}:
            self.remove_draw_handler(context)
            self.confirm(context)
            self.report({'INFO'}, "Finished")
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.remove_draw_handler(context)
            self.cancel(context)
            self.report({'INFO'}, "Cancelled")
            return {'CANCELLED'}

        elif event.type in {'WHEELDOWNMOUSE', 'WHEELUPMOUSE'}:
            if event.type == 'WHEELDOWNMOUSE':
                self.count_buffer -= 1
            elif event.type == 'WHEELUPMOUSE':
                self.count_buffer += 1

            self.count_buffer = max(self.count_buffer, 1)
            self.count = round(self.count_buffer)
            self.array_mod.count = self.count
            self.center(context)
            self.report({'INFO'}, f"Segments: {self.array_mod.count}")

        elif event.type == 'MOUSEMOVE' and self.adjusting != 'NONE':
            if self.adjusting == 'ANGLE':
                divisor = self.modal_scale * (100 if event.shift else 10)
                offset = event.mouse_region_x - self.mouse_prev_x
                self.angle_buffer -= offset / divisor / get_dpi_factor()
                self.angle_buffer = min(max(self.angle_buffer, 0), 360)
                self.angle = round(15 * round(self.angle_buffer / 15, 0) if event.ctrl else self.angle_buffer)
                self.deform_mod.angle = math.radians(self.angle)
                self.center(context)

            elif self.adjusting == 'DISPLACE':
                divisor = self.modal_scale * (2500 if event.shift else 250)
                offset = event.mouse_region_x - self.mouse_prev_x
                self.displace_buffer -= offset / divisor / get_dpi_factor()
                digits = 2 if event.ctrl and event.shift else 1 if event.ctrl else 3
                self.displace = round(self.displace_buffer, digits)
                self.displace_mod_one.strength = self.displace
                self.center(context)

            elif self.adjusting == 'SEGMENTS':
                divisor = self.modal_scale * (1000 if event.shift else 100)
                offset = event.mouse_region_x - self.mouse_prev_x
                self.count_buffer -= offset / divisor / get_dpi_factor()
                self.count_buffer = max(self.count_buffer, 1)
                self.count = round(self.count_buffer)
                self.array_mod.count = self.count
                self.center(context)

        elif event.type in {'S', 'D', 'A'} and event.value == 'PRESS':
            if event.type == 'S':
                self.adjusting = 'NONE' if self.adjusting == 'SEGMENTS' else 'SEGMENTS'
            elif event.type == 'D':
                self.adjusting = 'NONE' if self.adjusting == 'DISPLACE' else 'DISPLACE'
            elif event.type == 'A':
                self.adjusting = 'NONE' if self.adjusting == 'ANGLE' else 'ANGLE'

            if self.adjusting != 'NONE':
                self.report({'INFO'}, f"Adjusting {str(self.adjusting).capitalize()}")
            else:
                self.report({'INFO'}, "Stopped Adjusting")

        elif event.type == 'X' and event.value == 'PRESS':
            self.axis = "YZX"["XYZ".find(self.axis)]
            self.displace_mod_one.direction = 'X' if self.axis == 'Y' else 'Y'
            self.array_mod.relative_offset_displace = (1.0, 0.0, 0.0) if self.axis == 'Z' else (0.0, 0.0, 1.0)
            self.deform_mod.deform_axis = self.axis
            self.displace_mod_two.direction = 'X' if self.axis == 'Y' else 'Y'
            self.center(context)
            self.report({'INFO'}, f"Deform Axis: {self.axis}")

        elif event.type == 'H' and event.value == 'PRESS':
            get_preferences().property.hops_modal_help = not get_preferences().property.hops_modal_help
            context.area.tag_redraw()
            self.report({'INFO'}, f"{'Show' if get_preferences().property.hops_modal_help else 'Hide'} Help")

        self.mouse_prev_x = event.mouse_region_x
        return {'RUNNING_MODAL'}

    def center(self, context):
        temp = bpy.data.objects.new("Bounding Box", self.obj.data)
        bb = temp.bound_box[:]
        bpy.data.objects.remove(temp)

        right = left = bb[7][0]
        front = back = bb[7][1]
        top = bottom = bb[7][2]

        for i in range(7):
            x = bb[i][0]
            if x > right:
                right = x
            if x < left:
                left = x

            y = bb[i][1]
            if y > front:
                front = y
            if y < back:
                back = y

            z = bb[i][2]
            if z > top:
                top = z
            if z < bottom:
                bottom = z

        middle_x = (right + left) * 0.5
        middle_y = (front + back) * 0.5
        middle_z = (top + bottom) * 0.5

        verts = [v for v in bb]
        verts.append((right, middle_y, middle_z))
        verts.append((left, middle_y, middle_z))
        verts.append((middle_x, front, middle_z))
        verts.append((middle_x, back, middle_z))
        verts.append((middle_x, middle_y, top))
        verts.append((middle_x, middle_y, bottom))

        bm = bmesh.new()
        bm.from_mesh(self.obj.data)
        verts = [bm.verts.new(v) for v in verts]
        bm.to_mesh(self.obj.data)

        self.displace_mod_two.strength = 0.0
        context.view_layer.update()

        bb = self.obj.bound_box
        axis = 0 if self.axis == 'Y' else 1
        pos = neg = bb[7][axis]

        for i in range(7):
            val = bb[i][axis]
            if val > pos:
                pos = val
            if val < neg:
                neg = val

        offset = -0.5 * (pos + neg)
        self.displace_mod_two.strength = offset

        verts = [bm.verts.remove(v) for v in verts]
        bm.to_mesh(self.obj.data)
        bm.free()

    def confirm(self, context):
        modifier.sort(self.obj, sort_types=['WEIGHTED_NORMAL'])

        if self.weld_mod and not self.merge_segments:
            self.obj.modifiers.remove(self.weld_mod)

        if get_preferences().property.workflow == 'DESTRUCTIVE':
            for mod in [self.displace_mod_one, self.array_mod, self.deform_mod, self.displace_mod_two, self.weld_mod]:
                if mod:
                    modifier.apply(self.obj, mod=mod)

    def cancel(self, context):
        if self.displace_new_one:
            self.obj.modifiers.remove(self.displace_mod_one)
        else:
            self.displace_mod_one.direction = self.displace_settings_one["direction"]
            self.displace_mod_one.strength = self.displace_settings_one["strength"]

        if self.array_new:
            self.obj.modifiers.remove(self.array_mod)
        else:
            self.array_mod.use_constant_offset = self.array_settings["use_constant_offset"]
            self.array_mod.use_relative_offset = self.array_settings["use_relative_offset"]
            self.array_mod.use_object_offset = self.array_settings["use_object_offset"]
            self.array_mod.relative_offset_displace[0] = self.array_settings["displace_x"]
            self.array_mod.relative_offset_displace[1] = self.array_settings["displace_y"]
            self.array_mod.relative_offset_displace[2] = self.array_settings["displace_z"]
            self.array_mod.use_merge_vertices = self.array_settings["use_merge_vertices"]
            self.array_mod.fit_type = self.array_settings["fit_type"]
            self.array_mod.count = self.array_settings["count"]

        if self.deform_new:
            self.obj.modifiers.remove(self.deform_mod)
        else:
            self.deform_mod.deform_method = self.deform_settings["deform_method"]
            self.deform_mod.deform_axis = self.deform_settings["deform_axis"]
            self.deform_mod.angle = self.deform_settings["angle"]

        if self.displace_new_two:
            self.obj.modifiers.remove(self.displace_mod_two)
        else:
            self.displace_mod_two.direction = self.displace_settings_two["direction"]
            self.displace_mod_two.strength = self.displace_settings_two["strength"]

        if self.weld_new:
            self.obj.modifiers.remove(self.weld_mod)
        elif self.weld_mod:
            self.weld_mod.show_viewport = self.weld_settings["show_viewport"]

    def add_draw_handler(self, context):
        self.draw_handler = bpy.types.SpaceView3D.draw_handler_add(self.draw_ui, (context, ), "WINDOW", "POST_PIXEL")
        context.area.header_text_set(text=None)
        context.area.tag_redraw()

    def remove_draw_handler(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
        context.area.header_text_set(text=None)
        context.area.tag_redraw()

    def draw_ui(self, context):
        x = self.mouse_start_x
        y = self.mouse_start_y

        c1 = get_preferences().color.Hops_hud_color
        c2 = get_preferences().color.Hops_hud_help_color
        c3 = get_preferences().color.Hops_hud_text_color

        set_drawing_dpi(get_dpi())
        f = get_dpi_factor()
        o = 5

        l1 = (3, 23, 4, 43)
        l2 = (45, 23, 4, 95)
        l3 = (97, 23, 4, 167)
        l4 = (169, 23, 4, 224)

        vertices = (
            (x + (l1[0] - o) * f, y + l1[1] * f),
            (x + l1[0] * f, y + l1[2] * f),
            (x + (l1[3] - o) * f, y + l1[1] * f),
            (x + l1[3] * f, y + l1[2] * f),

            (x + (l2[0] - o) * f, y + l2[1] * f),
            (x + l2[0] * f, y + l2[2] * f),
            (x + (l2[3] - o) * f, y + l2[1] * f),
            (x + l2[3] * f, y + l2[2] * f),

            (x + (l3[0] - o) * f, y + l3[1] * f),
            (x + l3[0] * f, y + l3[2] * f),
            (x + (l3[3] - o) * f, y + l3[1] * f),
            (x + l3[3] * f, y + l3[2] * f),

            (x + (l4[0] - o) * f, y + l4[1] * f),
            (x + l4[0] * f, y + l4[2] * f),
            (x + (l4[3] - o) * f, y + l4[1] * f),
            (x + l4[3] * f, y + l4[2] * f))

        l1 = (l1[0] - 15, l1[1], l1[2], l1[0] - 6)

        vertices2 = (
            (x + (l1[0] - o) * f, y + l1[1] * f),
            (x + l1[0] * f, y + l1[2] * f),
            (x + (l1[3] - o) * f, y + l1[1] * f),
            (x + l1[3] * f, y + l1[2] * f))

        indices = (
            (0, 1, 2),
            (1, 2, 3),

            (4, 5, 6),
            (5, 6, 7),

            (8, 9, 10),
            (9, 10, 11),

            (12, 13, 14),
            (13, 14, 15))

        indices2 = (
            (0, 1, 2),
            (1, 2, 3))

        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)
        shader.bind()
        shader.uniform_float("color", c1)

        bgl.glEnable(bgl.GL_BLEND)
        batch.draw(shader)
        bgl.glDisable(bgl.GL_BLEND)

        shader2 = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch2 = batch_for_shader(shader2, 'TRIS', {"pos": vertices2}, indices=indices2)
        shader2.bind()
        shader2.uniform_float("color", c2)

        bgl.glEnable(bgl.GL_BLEND)
        batch2.draw(shader2)
        bgl.glDisable(bgl.GL_BLEND)

        draw_text(f"{self.axis}", x + 17 * f, y + 9 * f, size=12, color=c3)
        draw_text(f"{self.count}", x + 60 * f, y + 9 * f, size=12, color=c3)
        draw_text(f"{self.displace:.3f}", x + 107 * f, y + 9 * f, size=12, color=c3)
        draw_text(f"{self.angle:.0f}", x + 182 * f, y + 9 * f, size=12, color=c3)

        self.draw_help(context, x, y, f)

    def draw_help(self, context, x, y, f):
        c2 = get_preferences().color.Hops_hud_help_color

        if get_preferences().property.hops_modal_help:
            draw_text(" X - Increment Axis", x + 45 * f, y - 14 * f, size=11, color=c2)
            draw_text(" Scroll - Increment Segments", x + 45 * f, y - 26 * f, size=11, color=c2)
            draw_text(" S - Adjust Segments", x + 45 * f, y - 38 * f, size=11, color=c2)
            draw_text(" D - Adjust Displacement", x + 45 * f, y - 50 * f, size=11, color=c2)
            draw_text(" A - Adjust Angle", x + 45 * f, y - 62 * f, size=11, color=c2)
            draw_text(" H - Show/Hide Help", x + 45 * f, y - 74 * f, size=11, color=c2)

        else:
            draw_text(" H - Show/Hide Help", x + 45 * f, y - 14 * f, size=11, color=c2)
