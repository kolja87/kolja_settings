import bpy, bmesh, mathutils, math, copy
from ... preferences import get_preferences
from ... utils.objects import set_active


class HOPS_OT_Conv_To_Plane(bpy.types.Operator):
    bl_idname = "hops.to_plane"
    bl_label = "Hops To Plane"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = """Create a plane from the bounding box"""

    axis: bpy.props.EnumProperty(
        name="Axis",
        description="What axis to dice on",
        items=[
            ('+X', "+X", "Create a plane on the +X axis"),
            ('+Y', "+Y", "Create a plane on the +Y axis"),
            ('+Z', "+Z", "Create a plane on the +Z axis"),
            ('-X', "-X", "Create a plane on the -X axis"),
            ('-Y', "-Y", "Create a plane on the -Y axis"),
            ('-Z', "-Z", "Create a plane on the -Z axis")],
        default='+X')

    modified: bpy.props.BoolProperty(
        name="Modified",
        description="Take the bounding box dimensions from the modified object",
        default=True)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode == 'OBJECT'

    def draw(self, context):
        self.layout.prop(self, "axis")
        self.layout.prop(self, "modified")

    def execute(self, context):
        obj = context.active_object
        obj.select_set(False)

        if self.modified:
            context.view_layer.update()
            bb = obj.bound_box[:]

        else:
            temp = bpy.data.objects.new("Bounding Box", obj.data)
            bb = temp.bound_box[:]
            bpy.data.objects.remove(temp)

        plane = obj.copy()
        for col in obj.users_collection:
            col.objects.link(plane)

        plane.name = f"{obj.name} Plane {self.axis}"
        plane.modifiers.clear()
        plane.select_set(True)
        context.view_layer.objects.active = plane

        if self.axis == '+X':
            bb = (bb[7], bb[6], bb[5], bb[4])
        elif self.axis == '+Y':
            bb = (bb[3], bb[2], bb[6], bb[7])
        elif self.axis == '+Z':
            bb = (bb[5], bb[6], bb[2], bb[1])
        elif self.axis == '-X':
            bb = (bb[0], bb[1], bb[2], bb[3])
        elif self.axis == '-Y':
            bb = (bb[0], bb[4], bb[5], bb[1])
        elif self.axis == '-Z':
            bb = (bb[0], bb[3], bb[7], bb[4])

        bm = bmesh.new()
        verts = [bm.verts.new(v) for v in bb]
        bm.faces.new(verts)

        plane.data = bpy.data.meshes.new(f"{obj.name} Plane {self.axis}")
        bm.to_mesh(plane.data)
        bm.free()

        return {'FINISHED'}
