import bpy, bmesh, gpu, bgl, math
from gpu_extras.batch import batch_for_shader
from ... graphics.drawing2d import draw_text, set_drawing_dpi, draw_box
from ... utils.blender_ui import get_dpi, get_dpi_factor
from ... preferences import get_preferences
from ... utility import modifier


class HOPS_OT_RadialArray(bpy.types.Operator):
    bl_idname = "hops.radial_array"
    bl_label = "Radial Array"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING', 'GRAB_CURSOR'}
    bl_description = """LMB - Array around object center
Ctrl + LMB - Array around 3D cursor"""

    direction: bpy.props.EnumProperty(
        name="Direction",
        description="What axis to displace on",
        items=[
            ('X', "X", "Displace on the X axis"),
            ('Y', "Y", "Displace on the Y axis"),
            ('Z', "Z", "Displace on the Z axis")],
        default='Y')

    axis: bpy.props.EnumProperty(
        name="Axis",
        description="What axis to array around",
        items=[
            ('X', "X", "Array around the X axis"),
            ('Y', "Y", "Array around the Y axis"),
            ('Z', "Z", "Array around the Z axis")],
        default='Z')

    segments: bpy.props.IntProperty(
        name="Segments",
        description="How many copies to make",
        default=8,
        min=1)

    displace: bpy.props.FloatProperty(
        name="Displace",
        description="How far in or out to displace",
        default=0)

    cursor: bpy.props.BoolProperty(
        name="3D Cursor",
        description="Use the 3D cursor as origin",
        default=False)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode == 'OBJECT'

    def draw(self, context):
        self.layout.label(text=f"Direction: {self.direction}")
        self.layout.label(text=f"Axis: {self.axis}")
        self.layout.label(text=f"Segments: {self.segments}")
        self.layout.label(text=f"Displace: {self.displace:.3f}")
        self.layout.label(text=f"Origin: {'3D Cursor' if self.cursor else 'Object Center'}")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):

        # Set internal variables
        self.modal_scale = get_preferences().ui.Hops_modal_scale
        self.obj = context.active_object

        # Set internal variables
        self.empty = None
        self.displace_mod = None
        self.array_mod = None

        # Find empty and modifiers
        for a, b in zip(self.obj.modifiers[:-1], self.obj.modifiers[1:]):
            if a.type == 'DISPLACE' and b.type == 'ARRAY' and b.use_object_offset == True:
                self.empty = b.offset_object
                self.displace_mod = a
                self.array_mod = b
                break

        # Set internal variables
        self.empty_new = not self.empty
        self.displace_new = not self.displace_mod
        self.array_new = not self.array_mod

        # Create empty and modifiers
        if self.empty_new:
            self.empty = bpy.data.objects.new("Radial Empty", None)
            self.empty.empty_display_type = 'SPHERE'
            self.empty.parent = self.obj
            for col in self.obj.users_collection:
                col.objects.link(self.empty)

        if self.displace_new:
            self.displace_mod = self.obj.modifiers.new("Radial Displace", 'DISPLACE')
            self.displace_mod.show_expanded = False
            self.displace_mod.show_render = False
            self.displace_mod.show_in_editmode = True

            self.displace_mod.mid_level = 0.0
            self.displace_mod.direction = self.direction
            self.displace_mod.strength = self.displace

        if self.array_new:
            self.array_mod = self.obj.modifiers.new("Radial Array", 'ARRAY')
            self.array_mod.show_expanded = False
            self.array_mod.show_render = False
            self.array_mod.show_in_editmode = True

            self.array_mod.use_constant_offset = False
            self.array_mod.use_relative_offset = False
            self.array_mod.use_object_offset = True
            self.array_mod.offset_object = self.empty
            self.array_mod.count = self.segments

        # Set internal variables
        self.direction = self.displace_mod.direction
        self.axis = "YZX"["XYZ".find(self.direction)]
        self.segments = self.segments_buffer = self.array_mod.count
        self.displace = self.displace_buffer = self.displace_mod.strength

        # Try to find the axis from the empty's drivers
        if self.empty.animation_data:
            for fcurve in self.empty.animation_data.drivers:
                if fcurve.data_path == "rotation_euler":
                    self.axis = "XYZ"[fcurve.array_index]

        # Store modifier settings
        self.displace_settings = {}
        self.displace_settings["show_viewport"] = self.displace_mod.show_viewport
        self.displace_settings["mid_level"] = self.displace_mod.mid_level
        self.displace_settings["direction"] = self.displace_mod.direction
        self.displace_settings["strength"] = self.displace_mod.strength

        self.array_settings = {}
        self.array_settings["use_constant_offset"] = self.array_mod.use_constant_offset
        self.array_settings["use_relative_offset"] = self.array_mod.use_relative_offset
        self.array_settings["use_object_offset"] = self.array_mod.use_object_offset
        self.array_settings["offset_object"] = self.array_mod.offset_object
        self.array_settings["count"] = self.array_mod.count

        # Configure existing modifiers
        if not self.displace_new:
            self.displace_mod.mid_level = 0.0
            self.displace_mod.direction = self.direction
            self.displace_mod.strength = self.displace

        if not self.array_new:
            self.array_mod.use_constant_offset = False
            self.array_mod.use_relative_offset = False
            self.array_mod.use_object_offset = True
            self.array_mod.offset_object = self.empty
            self.array_mod.count = self.segments

        # Move object origin
        self.location = self.obj.location[:]
        self.cursor_prev = bool(self.cursor)
        self.cursor = event.ctrl and event.type == 'LEFTMOUSE'

        if self.empty_new:
            self.set_origin(context)
        else:
            self.cursor = self.origin_outside_bounds(context)

        # Create driver
        self.direction_prev = str(self.direction)
        self.axis_prev = str(self.axis)
        self.create_driver(context)

        # Store mouse position
        self.mouse_prev_x = event.mouse_region_x
        self.mouse_start_x = event.mouse_region_x
        self.mouse_start_y = event.mouse_region_y

        # Set internal variables
        self.adjusting = 'NONE' if self.cursor else 'DISPLACE'
        self.displace_center = float(self.displace)
        self.displace_cursor = float(self.displace)
        self.set_displace(context)

        # Start operation
        self.add_draw_handler(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MIDDLEMOUSE':
            return {'PASS_THROUGH'}

        elif event.type == 'Z' and (event.shift or event.alt):
            return {'PASS_THROUGH'}

        elif event.type in {'LEFTMOUSE', 'SPACE'}:
            self.remove_draw_handler(context)
            self.confirm(context)
            self.report({'INFO'}, "Finished")
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.remove_draw_handler(context)
            self.cancel(context)
            self.report({'INFO'}, "Cancelled")
            return {'CANCELLED'}

        elif event.type == 'H' and event.value == 'PRESS':
            get_preferences().property.hops_modal_help = not get_preferences().property.hops_modal_help
            context.area.tag_redraw()
            self.report({'INFO'}, f"{'Show' if get_preferences().property.hops_modal_help else 'Hide'} Help")

        elif event.type == 'A' and event.value == 'PRESS':
            self.displace_mod.show_viewport = not self.displace_mod.show_viewport
            self.report({'INFO'}, f"{'Enabled' if self.displace_mod.show_viewport else 'Disabled'} Displacement")

        elif event.type == 'S' and event.value == 'PRESS':
            self.adjusting = 'NONE' if self.adjusting == 'SEGMENTS' else 'SEGMENTS'
            self.report({'INFO'}, f"{'Started' if self.adjusting == 'SEGMENTS' else 'Stopped'} Adjusting Segments")

        elif event.type == 'D' and event.value == 'PRESS':
            self.adjusting = 'NONE' if self.adjusting == 'DISPLACE' else 'DISPLACE'
            self.report({'INFO'}, f"{'Started' if self.adjusting == 'DISPLACE' else 'Stopped'} Adjusting Displace")

        elif event.type == 'Z' and event.value == 'PRESS':
            self.direction = "YZX"["XYZ".find(self.direction)]
            self.displace_mod.direction = self.direction
            self.report({'INFO'}, f"Displace Axis: {self.direction}")

        elif event.type == 'X' and event.value == 'PRESS':
            self.direction = "YZX"["XYZ".find(self.direction)]
            self.displace_mod.direction = self.direction
            self.axis = "YZX"["XYZ".find(self.axis)]
            self.create_driver(context)
            self.report({'INFO'}, f"Rotate Axis: {self.axis}")

        elif event.type == 'C' and event.value == 'PRESS':
            self.adjusting = 'NONE'
            self.cursor = not self.cursor
            self.set_displace(context)
            self.set_origin(context)
            self.create_driver(context)
            self.report({'INFO'}, f"Origin: {'3D Cursor' if self.cursor else 'Object Center'}")

        elif event.type in {'WHEELDOWNMOUSE', 'WHEELUPMOUSE'}:
            self.segments_buffer += 1 if event.type == 'WHEELUPMOUSE' else -1
            self.segments_buffer = max(self.segments_buffer, 1)
            self.segments = round(self.segments_buffer)
            self.array_mod.count = self.segments
            self.report({'INFO'}, f"Segments: {self.segments}")

        elif event.type == 'MOUSEMOVE' and self.adjusting == 'SEGMENTS':
            divisor = self.modal_scale * (1000 if event.shift else 100)
            offset = event.mouse_region_x - self.mouse_prev_x
            self.segments_buffer -= offset / divisor / get_dpi_factor()
            self.segments_buffer = max(self.segments_buffer, 1)
            self.segments = round(self.segments_buffer)
            self.array_mod.count = self.segments

        elif event.type == 'MOUSEMOVE' and self.adjusting == 'DISPLACE':
            divisor = self.modal_scale * (2500 if event.shift else 250)
            offset = event.mouse_region_x - self.mouse_prev_x
            self.displace_buffer -= offset / divisor / get_dpi_factor()
            digits = 2 if event.ctrl and event.shift else 1 if event.ctrl else 3
            self.displace = round(self.displace_buffer, digits)
            self.displace_mod.strength = self.displace

        self.mouse_prev_x = event.mouse_region_x
        return {'RUNNING_MODAL'}

    def set_displace(self, context):
        if self.cursor:
            self.displace_center = float(self.displace)
            self.displace_buffer = self.displace_cursor
            self.displace = self.displace_cursor
            self.displace_mod.strength = self.displace_cursor

        else:
            self.displace_cursor = float(self.displace)
            self.displace_buffer = self.displace_center
            self.displace = self.displace_center
            self.displace_mod.strength = self.displace_center

    def set_origin(self, context):
        self.empty.parent = None
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR' if self.cursor else 'ORIGIN_GEOMETRY', center='BOUNDS')
        self.empty.parent = self.obj
        self.empty.location = (0,0,0)
        self.empty.rotation_euler = (0,0,0)
        self.empty.scale = (1,1,1)

    def origin_outside_bounds(self, context):
        temp = bpy.data.objects.new("Bounding Box", self.obj.data)
        bb = temp.bound_box[:]
        bpy.data.objects.remove(temp)
        x = bb[6][0] < 0 or bb[0][0] > 0
        y = bb[6][1] < 0 or bb[0][1] > 0
        z = bb[6][2] < 0 or bb[0][2] > 0
        return x or y or z

    def create_driver(self, context):
        [self.empty.driver_remove("rotation_euler", i) for i in range(3)]
        self.empty.rotation_euler = (0,0,0)
        index = "XYZ".find(self.axis)
        self.driver = self.empty.driver_add("rotation_euler", index).driver
        count = self.driver.variables.new()
        count.name = "count"
        count.targets[0].id = self.obj
        count.targets[0].data_path = f"modifiers[\"{self.array_mod.name}\"].count"
        self.driver.expression = f"{math.radians(360)} / count"

    def confirm(self, context):
        modifier.sort(self.obj, sort_types=['WEIGHTED_NORMAL'])

        if get_preferences().property.workflow == 'DESTRUCTIVE':
            modifier.apply(self.displace_mod)
            modifier.apply(self.array_mod)
            bpy.data.objects.remove(self.empty)

    def cancel(self, context):
        self.direction = self.direction_prev
        self.axis = self.axis_prev

        self.empty.parent = None
        cursor = context.scene.cursor.location[:]
        context.scene.cursor.location = self.location[:]
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='BOUNDS')
        context.scene.cursor.location = cursor[:]
        self.empty.parent = self.obj
        self.empty.location = (0,0,0)
        self.empty.rotation_euler = (0,0,0)
        self.empty.scale = (1,1,1)

        if self.displace_new:
            self.obj.modifiers.remove(self.displace_mod)
        else:
            self.displace_mod.show_viewport = self.displace_settings["show_viewport"]
            self.displace_mod.mid_level = self.displace_settings["mid_level"]
            self.displace_mod.direction = self.displace_settings["direction"]
            self.displace_mod.strength = self.displace_settings["strength"]

        if self.array_new:
            self.obj.modifiers.remove(self.array_mod)
        else:
            self.array_mod.use_constant_offset = self.array_settings["use_constant_offset"]
            self.array_mod.use_relative_offset = self.array_settings["use_relative_offset"]
            self.array_mod.use_object_offset = self.array_settings["use_object_offset"]
            self.array_mod.offset_object = self.array_settings["offset_object"]
            self.array_mod.count = self.array_settings["count"]

        if self.empty_new:
            bpy.data.objects.remove(self.empty)
        else:
            self.create_driver(context)

    def add_draw_handler(self, context):
        self.draw_handler = bpy.types.SpaceView3D.draw_handler_add(self.draw_ui, (context, ), "WINDOW", "POST_PIXEL")
        context.area.header_text_set(text=None)
        context.area.tag_redraw()

    def remove_draw_handler(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, "WINDOW")
        context.area.header_text_set(text=None)
        context.area.tag_redraw()

    def draw_ui(self, context):
        x = self.mouse_start_x
        y = self.mouse_start_y

        c1 = get_preferences().color.Hops_hud_color
        c2 = get_preferences().color.Hops_hud_help_color
        c3 = get_preferences().color.Hops_hud_text_color

        set_drawing_dpi(get_dpi())
        f = get_dpi_factor()
        o = 5

        l1 = (3, 23, 4, 43)
        l2 = (45, 23, 4, 95)
        l3 = (97, 23, 4, 167)

        vertices1 = (
            (x + (l1[0] - o) * f, y + l1[1] * f),
            (x + l1[0] * f, y + l1[2] * f),
            (x + (l1[3] - o) * f, y + l1[1] * f),
            (x + l1[3] * f, y + l1[2] * f),

            (x + (l2[0] - o) * f, y + l2[1] * f),
            (x + l2[0] * f, y + l2[2] * f),
            (x + (l2[3] - o) * f, y + l2[1] * f),
            (x + l2[3] * f, y + l2[2] * f),

            (x + (l3[0] - o) * f, y + l3[1] * f),
            (x + l3[0] * f, y + l3[2] * f),
            (x + (l3[3] - o) * f, y + l3[1] * f),
            (x + l3[3] * f, y + l3[2] * f))

        l1 = (l1[0] - 15, l1[1], l1[2], l1[0] - 6)

        vertices2 = (
            (x + (l1[0] - o) * f, y + l1[1] * f),
            (x + l1[0] * f, y + l1[2] * f),
            (x + (l1[3] - o) * f, y + l1[1] * f),
            (x + l1[3] * f, y + l1[2] * f))

        indices1 = (
            (0, 1, 2),
            (1, 2, 3),

            (4, 5, 6),
            (5, 6, 7),

            (8, 9, 10),
            (9, 10, 11))

        indices2 = (
            (0, 1, 2),
            (1, 2, 3))

        shader1 = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch1 = batch_for_shader(shader1, 'TRIS', {"pos": vertices1}, indices=indices1)
        shader1.bind()
        shader1.uniform_float("color", c1)

        bgl.glEnable(bgl.GL_BLEND)
        batch1.draw(shader1)
        bgl.glDisable(bgl.GL_BLEND)

        shader2 = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch2 = batch_for_shader(shader2, 'TRIS', {"pos": vertices2}, indices=indices2)
        shader2.bind()
        shader2.uniform_float("color", c2)

        bgl.glEnable(bgl.GL_BLEND)
        batch2.draw(shader2)
        bgl.glDisable(bgl.GL_BLEND)

        draw_text(f"{self.axis}", x + 17 * f, y + 9 * f, size=12, color=c3)
        draw_text(f"{self.segments}", x + 60 * f, y + 9 * f, size=12, color=c3)
        draw_text(f"{self.displace:.3f}", x + 107 * f, y + 9 * f, size=12, color=c3)

        help_text = [
            " Scroll - Increment Segments",
            " A - Toggle Displace",
            " S - Adjust Segments",
            " D - Adjust Displace",
            " Z - Increment Displace Axis",
            " X - Increment Rotate Axis",
            " C - Array Around 3D Cursor / Object Center",
            " H - Show / Hide Help"]

        if get_preferences().property.hops_modal_help:
            for index, text in enumerate(help_text):
                draw_text(text, x + 45 * f, y - 14 * (index + 1) * f, size=11, color=c2)

        else:
            draw_text(" H - Show / Hide Help", x + 45 * f, y - 14 * f, size=11, color=c2)
