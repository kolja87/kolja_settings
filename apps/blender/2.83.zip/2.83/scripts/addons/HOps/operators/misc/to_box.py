import bpy
import bmesh
import bpy.utils.previews
from math import radians
from ... preferences import get_preferences
from ... utils.blender_ui import get_dpi_factor
from ... utils.context import ExecutionContext
from bpy.props import EnumProperty, FloatProperty, BoolProperty
from mathutils import Vector

class HOPS_OT_Conv_To_Box(bpy.types.Operator):
    bl_idname = "hops.to_box"
    bl_label = "Convert Selection to a bounding box"
    bl_options = {'REGISTER'}
    bl_description = """Converts selection to bounding box.

"""
    make_wire: bpy.props.BoolProperty(
        name="Set Wire",
        description="Sets bounding shape to be wire.",
        default=False)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.prop(self, "make_wire")

    def execute(self, context):
        
        selected = bpy.context.selected_objects
        for obj in selected:
            #calculate bounding box centre in object space
            center = sum((Vector(b) for b in obj.bound_box), Vector())
            center /= 8
            #multply object's world transform matrix by bounding box center
            #to get box center in world space coordinate
            center_world = obj.matrix_world @ center
            #spawbn cube and copy loc rot and dimensions                        
            bpy.ops.mesh.primitive_cube_add()          
            #get global space rotation of target object to account for inherited transform
            bpy.context.active_object.rotation_euler = obj.matrix_world.to_euler()
            bpy.context.active_object.location = center_world
            bpy.context.active_object.dimensions = obj.dimensions
            #lattice shenanigans
            if obj.type == 'LATTICE':
                obj.select_set(True)
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.parent_set(type='LATTICE')                
            self.report({'INFO'}, F'Box Created')
        return {'FINISHED'}
