import bpy


class HOPS_OT_MOD_Weighted_Normal(bpy.types.Operator):
    bl_idname = "hops.mod_weighted_normal"
    bl_label = "Add Weighted Normal Modifier"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = """LMB - Add Weighted Normal Modifier
LMB + SHIFT - Add Weighted Normal Modifier with Keep Sharp option"""

    keep_sharp: bpy.props.BoolProperty(
        name="Keep Sharp",
        description="",
        default=False)

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def draw(self, context):
        self.layout.prop(self, "keep_sharp")

    def invoke(self, context, event):
        self.keep_sharp = event.shift
        return self.execute(context)

    def execute(self, context):
        for obj in [o for o in context.selected_objects if o.type == 'MESH']:
            obj.data.use_auto_smooth = True
            for f in obj.data.polygons:
                f.use_smooth = True

            for mod in obj.modifiers:
                if mod.type == 'WEIGHTED_NORMAL':
                    obj.modifiers.remove(mod)

            if obj.hops.status != 'BOOLSHAPE':
                mod = obj.modifiers.new(name="Weighted Normal", type='WEIGHTED_NORMAL')
                mod.keep_sharp = self.keep_sharp

        return {"FINISHED"}
