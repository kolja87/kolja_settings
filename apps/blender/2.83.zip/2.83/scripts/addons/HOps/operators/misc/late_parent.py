import bpy
from ... utility import modifier
from bpy.props import EnumProperty

class HOPS_OT_LateParen_t(bpy.types.Operator):
    bl_idname = "hops.late_paren_t"
    bl_label = "Late Parent "
    bl_description = '\n Connects cutters as children to parent'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {"REGISTER", "UNDO"}


    def execute(self, context):
        targets = {}

        for obj in context.visible_objects:
            for mod in obj.modifiers:
                if mod.type == 'BOOLEAN' and mod.object and mod.object.select_get():
                    if obj not in targets:
                        targets[obj] = [mod.object]
                    elif mod.object not in targets[obj]:
                        targets[obj].append(mod.object)

        count = 0
        for obj in targets:
            context_override = context.copy()
            context_override['object'] = obj
            bpy.ops.object.parent_set(context_override, keep_transform=True)

            for _ in targets[obj]:
                count += 1

        del targets

        self.report({'INFO'}, F'{str(count) + " " if count > 0 else ""}Cutter{"s" if count > 1 else ""} Parented')

        return {'FINISHED'}


class HOPS_OT_LateParent(bpy.types.Operator):
    bl_idname = "hops.late_parent"
    bl_label = "Late Parent "
    bl_description = '\n Connects cutters as children to parent'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {"REGISTER", "UNDO"}


    def execute(self, context):
        targets = []

        for obj in context.selected_objects:
            for mod in obj.modifiers:
                if mod.type == 'BOOLEAN' and mod.object != None:
                    if mod.object not in targets:
                        targets.append(mod.object)
            for target in targets:
                #check cutters parent. skip if it's itself or it's already parented to the object 
                #to avoid jump that would require additional workaround
                # also skip if cutter already has a different parent to not mess with user's parenting
                if target == obj or target.parent == obj or target.parent != None:
                    continue
                target.parent = obj
                target.matrix_parent_inverse = obj.matrix_world.inverted()
        
        del targets
        self.report({'INFO'}, F'Cutters Parented')

        return {'FINISHED'}
