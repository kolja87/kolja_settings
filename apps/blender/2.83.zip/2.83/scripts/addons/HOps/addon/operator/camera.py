import bpy
import math

from bpy.types import Operator
from bpy.props import IntProperty, BoolProperty
from bpy.utils import register_class, unregister_class
from math import radians


class HOPS_OT_camera_rig(Operator):
    bl_idname = 'hops.camera_rig'
    bl_label = 'Camera Rig'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = '''Set up a turntable camera rig

Ctrl + LMB - Don't make the new camera active in the scene 
Shift + LMB - Don't enable passepartout on the new camera'''

    rotations: IntProperty(
        name='Rotations',
        description='How many circles the camera should turn',
        min=1,
        soft_max=10,
        default=2)

    make_active: BoolProperty(
        name='Make Active',
        description='Make the new camera the active one in the scene',
        default=True)

    passepartout: BoolProperty(
        name='Passepartout',
        description='Enable passepartout on the camera',
        default=True)

    def invoke(self, context, event):
        self.make_active = not event.ctrl
        self.passepartout = not event.shift
        return self.execute(context)

    def draw(self, context):
        self.layout.prop(self, 'rotations')
        row = self.layout.row()
        row.prop(self, 'make_active')
        row.prop(self, 'passepartout')

    def execute(self, context):
        # create camera
        data = bpy.data.cameras.new(name='Camera')
        cam = bpy.data.objects.new(name='Camera', object_data=data)
        context.collection.objects.link(cam)

        # make camera active
        if self.make_active:
            context.scene.camera = cam

        # enable passepartout
        if self.passepartout:
            cam.data.passepartout_alpha = 1

        # create empty
        empty = bpy.data.objects.new(name='Empty', object_data=None)
        context.collection.objects.link(empty)

        # create empty driver
        driver = empty.driver_add('rotation_euler', 2).driver
        driver.expression = f'(frame - frame_start) * (2 * pi) / (1 + frame_end - frame_start) * {self.rotations}'

        # create frame start variable
        frame_start = driver.variables.new()
        frame_start.name = 'frame_start'
        frame_start.targets[0].id_type = 'SCENE'
        frame_start.targets[0].id = context.scene
        frame_start.targets[0].data_path = 'frame_start'

        # create frame end variable
        frame_end = driver.variables.new()
        frame_end.name = 'frame_end'
        frame_end.targets[0].id_type = 'SCENE'
        frame_end.targets[0].id = context.scene
        frame_end.targets[0].data_path = 'frame_end'

        # parent camera to empty
        cam.parent = empty

        # move camera into place
        cam.location.z = 1
        cam.location.y = -12

        # add constraint
        con = cam.constraints.new(type='DAMPED_TRACK')
        con.target = empty
        con.track_axis = 'TRACK_NEGATIVE_Z'

        return {'FINISHED'}


def register():
    register_class(HOPS_OT_camera_rig)


def unregister():
    unregister_class(HOPS_OT_camera_rig)
