import bpy

from mathutils import Vector

from bpy.types import PropertyGroup
from bpy.props import BoolProperty, FloatVectorProperty, FloatProperty

from ... utility import names


class hops(PropertyGroup):

    use_dpi_factoring: BoolProperty(
        name = 'Popup Dpi Factoring',
        description = 'Automatically determine UI scale for popups',
        default = True)

    Hops_modal_scale: FloatProperty(
        name="Modal Operators Scale",
        description="Modal Operators Scale",
        default=1, min=0.001, max=100)

    use_helper_popup: BoolProperty(
        name="Use Helper as Pop-up",
        default=False,
        description="Use helper pop-up instead of OK dialogue")

    use_bevel_helper_popup: BoolProperty(
        name="Use Bevel Helper as Pop-up",
        default=True,
        description="Use bevel helper pop-up instead of OK dialogue")

    use_kitops_popup: BoolProperty(
        name="Use KITOPS as Pop-up",
        default=True,
        description="Use KITOPS pop-up instead of OK dialogue")


def label_row(path, prop, row, label=''):
    row.label(text=label if label else names[prop])
    row.prop(path, prop, text='')


def draw(preference, context, layout):
    layout.label(text='Hardops UI:')


    label_row(preference.ui, 'Hops_modal_scale', layout.row(), label='Modal Scale')
    label_row(preference.ui, 'use_dpi_factoring', layout.row(), label='Popup Dpi Factoring')
    label_row(preference.ui, 'use_helper_popup', layout.row(), label='Helper popup')
    label_row(preference.ui, 'use_bevel_helper_popup', layout.row(), label='Bevel Helper popup')
    label_row(preference.ui, 'use_kitops_popup', layout.row(), label='Use KITOPS popup')
